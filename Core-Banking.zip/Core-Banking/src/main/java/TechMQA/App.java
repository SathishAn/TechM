package TechMQA;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

/**
 * Hello world!
 *
 */
public class App 
{
	
	static WebDriver driver;
	
	@Test
    public static void Sample()
    {
		driver =  new ChromeDriver();
        System.out.println( "Hello World!".substring(0,1) );
       
        
    }
}
