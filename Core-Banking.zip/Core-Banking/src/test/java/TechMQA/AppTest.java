package TechMQA;

public class AppTest {
 public static void main(String[] args) {

	   SBI sb = new SBI();
		sb.anotherRule();
		sb.rule(26000);
	   
   }
	
	
	
}
