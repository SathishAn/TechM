package TechMQA;

public class RBI {
	
	public void rule(int amt) {
		if(amt > 50000) {
			System.out.println("amount limit crossed 50000");
		}
		
	}
	
	public void anotherRule() {
		System.out.println("Another Rule");
	}

}
