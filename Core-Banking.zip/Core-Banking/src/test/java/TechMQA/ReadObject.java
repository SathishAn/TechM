package TechMQA;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.commons.exec.launcher.Java13CommandLauncher;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.support.How;


public class ReadObject {
	static Map<String, String> identifiedObjects;
	static Map<String, String> identifiedAttributes;
	static Map<String, String> identifiedName;
	
	static HashMap<String, String> newObject;
	static HashMap<String, String> newattributes;
	static HashMap<String, String> newObjectName;
	static Map<String, String> existingObject;
	static Map<String, String> existObjAttributes;
	static HashMap<String, String> existingObjectComments;
	public static void createPageFactory(String pageName) {
	
	//public static void main(String[] args) {
		
		String path = "./src/test/resources/Datatable/accelator.xlsx";
		//pageName = "ObjectRepository";
		identifiedObjects = new TreeMap<String, String>();
		identifiedAttributes = new HashMap<String, String>();
		identifiedName = new HashMap<String, String>();
		
		newObjectName = new HashMap<String, String>();
		newObject = new HashMap<String, String>();
		newattributes = new HashMap<String, String>();
		
		
		
		File file = new File(path);
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(file);
		
		XSSFWorkbook workbook=new XSSFWorkbook(inputStream);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println(rowCount);
		Row row = sheet.getRow(0);
		String objectName = null, attribute = null, fieldType = null;
		int colCount = row.getLastCellNum();
		for (int i=1 ; i <= rowCount ; i++){			
			String fieldText = null;
			row = sheet.getRow(i);
			System.out.println(row.getCell(1).getStringCellValue());
			if (!(row.getCell(0) == null || row.getCell(0).toString().isEmpty() )){
				
				fieldText	= row.getCell(0).getStringCellValue();
			}
			if (!(row.getCell(1) == null)){
				fieldType = row.getCell(1).getStringCellValue();
			}	
			if (!(row.getCell(2) == null || row.getCell(2).toString().isEmpty() )){
				attribute = "ID";
				 objectName	= row.getCell(2).getStringCellValue();
			}else if (!(row.getCell(3) == null || row.getCell(3).toString().isEmpty())){
				attribute = "name";
				 objectName	= row.getCell(3).getStringCellValue();
			}else if (!(row.getCell(5) == null || row.getCell(5).toString().isEmpty())){
				attribute = "Class";
				 objectName	= row.getCell(5).getStringCellValue();
			}else if (!(row.getCell(9) == null || row.getCell(9).toString().isEmpty())){
					attribute = "Link";
				 objectName	= row.getCell(9).getStringCellValue();
			}else if(!(row.getCell(10) == null || row.getCell(10).toString().isEmpty())){
			/*	attribute = "Xpath";
			 objectName	= row.getCell(10).getStringCellValue();*/
		}
			
			identifiedObjects.put(objectName, fieldType);
			identifiedAttributes.put(objectName, attribute);
			if (!(identifiedName.containsKey(objectName))){
				if  (identifiedName.containsValue(fieldText)){					
					identifiedName.put(objectName, fieldText);
				}else{
					
					identifiedName.put(objectName, fieldText);
				}
			/*
			newObject.put(objectName, fieldType);
			newattributes.put(objectName, attribute);
			if (!(newObjectName.containsKey(objectName))){
				if  (newObjectName.containsValue(fieldText)){					
					newObjectName.put(objectName, fieldText);
				}else{
					
					newObjectName.put(objectName, fieldText);
				}*/
			}
			
		}
		
		for (Entry<String, String> entry: identifiedObjects.entrySet()){
			System.out.println(entry.getKey() + "-" +entry.getValue());
		}
		for (Entry<String, String> entry: identifiedAttributes.entrySet()){
			System.out.println(entry.getKey() + "-" +entry.getValue());
		}
		changeClass(pageName);
		mapComparison(pageName);		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	
	
	public static void changeClass(String pageName){		
		existingObject = new TreeMap<String, String>();
		existObjAttributes = new HashMap<String, String>();
		existingObjectComments = new HashMap<String, String>();
		 String indexValues = "";
		File javaFile = new File("./src/test/java/TechMQA/" +pageName + ".java");
		try {
			BufferedReader br = new BufferedReader(new FileReader(javaFile));
            String st;
            while((st = br.readLine()) != null){
            	String sPrefix = "@FindBy";
            	if (st.contains(sPrefix)){ 
            		StringBuffer objectAttributes = new StringBuffer();
            		StringBuffer objectName = new StringBuffer();
            		 int len = sPrefix.length();
            		 String variable = st.substring(st.indexOf(sPrefix));
            		 variable = variable.substring(len+1);
            		 System.out.println(variable);
            		 objectName.append(variable.substring(variable.indexOf("WebElement")+10).trim().replace(";", ""));
            		 System.out.println(objectName.toString());
            		 variable = variable.substring(0, variable.indexOf(")"));
            		String[] varSplit = variable.split(",");
            		String variableKey = varSplit[0].substring(varSplit[0].indexOf("=")+1).replace("\"", "");            		
            		String variableValue =varSplit[1].substring(varSplit[1].indexOf("=")+1).replace("\"", "");
            		
            		existingObject.put(objectName.toString().trim(), variableValue.trim());
            		existObjAttributes.put(objectName.toString().trim(), variableKey.trim());
            				 
            	}else{
            		if(!st.isEmpty()){
            			indexValues = indexValues + st;
            		}
            	}
            
            }
            
            for (Entry<String, String> entry: existingObject.entrySet()){
    			System.out.println(entry.getKey() + "-" +entry.getValue());
    		}
		
		
	}catch(Exception e){
		System.out.println(e);
		
	}
		
	}

public static void mapComparison(String pageName) throws IOException{
	String comparisonValue = null;
	String comparisonAttributes = null;
	ArrayList<String> newlist = new ArrayList<String>();
	HashMap<String, String> propertyChange = new HashMap<String, String>();		
	for (String k:identifiedObjects.keySet() ){
			
			if(!(identifiedName.get(k)== null || identifiedName.get(k).isEmpty())){
				
				if (!existingObject.containsKey(identifiedName.get(k))){
					System.out.println(k);
					newlist.add(k);
				}else{
						
						switch(identifiedAttributes.get(k)){
						
							case "ID":
								comparisonAttributes = "How.ID";
								comparisonValue = k;
								break;
								
							case "name":
								comparisonAttributes = "How.NAME";
								comparisonValue = k;
								break;
								
							case "Class":
								comparisonAttributes = "How.CLASS";
								comparisonValue = k;
								break;
							case "Link":
								comparisonValue = k;
								break;
							case "Xpath":
								comparisonAttributes = "How.XPATH";
								comparisonValue = k;
								break;
							
							default:
								break;
						
						}
									
						System.out.println(existingObject.get(identifiedName.get(k)).toString() + " ------- "+ comparisonValue.toString() );
						
					 if(!existingObject.get(identifiedName.get(k)).equalsIgnoreCase(comparisonValue.toString())){
						 existingObject.put(identifiedName.get(k), comparisonValue);
						 existObjAttributes.put(identifiedName.get(k), comparisonAttributes);
						 propertyChange.put(identifiedName.get(k), "Yes");
						 
					 }
				}
				
			}else{
				if (!existingObject.containsKey(k)){
					System.out.println(k);
					newlist.add(k);
				}else{
					
					switch(identifiedAttributes.get(k)){
					
					case "ID":
						comparisonAttributes = "How.ID";
						comparisonValue = k;
						break;
						
					case "name":
						comparisonAttributes = "How.NAME";
						comparisonValue = k;
						break;
						
					case "Class":
						comparisonAttributes = "How.CLASS";
						comparisonValue = k;
						break;
					case "Link":
						comparisonValue = k;
						break;
					case "Xpath":
						comparisonAttributes = "How.XPATH";
						comparisonValue = k;
						break;
					
					default:
						break;
				
				}
							
				System.out.println(existingObject.get(newObjectName.get(k)) + " ------- "+ comparisonValue.toString() );
				
				 if(!existingObject.get(identifiedName.get(k)).equalsIgnoreCase(comparisonValue.toString())){
					 existingObject.put(identifiedName.get(k), comparisonValue);
					 existObjAttributes.put(identifiedName.get(k), comparisonAttributes);
					 propertyChange.put(identifiedName.get(k), "Yes");
					 
				 }
					
				}
			
			}
		}
	
	File javaFile = new File("./src/test/java/TechMQA/" +pageName + ".java");	
	BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(javaFile)));
	String FileContent = null;
	String outputValue = null;	
	writer.write("package TechMQA;\n\n");	
	writer.write("import java.util.List;\nimport org.openqa.selenium.By;\nimport org.openqa.selenium.By;\r\n" + 
			"import org.openqa.selenium.WebElement;\r\n" + 
			"import org.openqa.selenium.support.FindBy;\r\n" + 
			"import utilities.CoreTapWrappers;\r\n"+
			"import org.openqa.selenium.support.How;\n\n");
	writer.write("public class " + pageName + " extends CoreTapWrappers {\n\n");	
	
	
	for (String key:existingObject.keySet() ){
		if(propertyChange.containsKey(key)){
			String timeStamp = new SimpleDateFormat("dd.MM.yyyy - HH.mm.ss").format(new Date());
			writer.write("\n //Modification done on object property - " + timeStamp);
			
		}
		
		
		
		
		writer.write("\n\n @FindBy(how=" + existObjAttributes.get(key) + ", using=\"" + existingObject.get(key) +"\") WebElement " + key +  ";" );
		
	}
	
	
	for(int i=0;i< newlist.size(); i++){
		String newValue;
		if(!(identifiedName.get(newlist.get(i)) == null || identifiedName.get(newlist.get(i)).isEmpty())){
			newValue = identifiedName.get(newlist.get(i));
		}
		else{
			newValue = newlist.get(i);
		}
		String timeStamp = new SimpleDateFormat("dd.MM.yyyy - HH.mm.ss").format(new Date());
		writer.write("\n //New Object added - " + timeStamp);
		writer.write("\n\n  @FindBy(how=");
	//writer.write("\n\n public static final By " + newValue  + " = ");
	String sAttribute = identifiedAttributes.get(newlist.get(i));
	
	switch (sAttribute) {
	case "ID":
		outputValue = "How.ID, using= \""+ newlist.get(i)+"\")";
		break;
		
	case "name":
		outputValue = "By.name(\""+ newlist.get(i)+"\")";
		break;
		
	case "Class":
		outputValue = "By.className(\""+ newlist.get(i)+"\")";
		break;
	case "Link":
		outputValue = "How.LINK_TEXT, using= \""+ newlist.get(i)+"\")";
		break;
	case "Xpath":
		outputValue = "By.xpath(\""+  newlist.get(i) +"\");";
		break;
	
	default:
		break;
	}
	if (identifiedObjects.get(newlist.get(i)).equalsIgnoreCase("radio")){
		writer.write(outputValue + " List<WebElement> " + newValue + ";");
	}else {
		writer.write(outputValue + " WebElement " + newValue + ";");
	}
	
	
	
	}
    
    
       
	for(int i=0;i< newlist.size(); i++){
		String new_Value = identifiedObjects.get(newlist.get(i));
		String newValue;
		if(!(identifiedName.get(newlist.get(i)) == null || identifiedName.get(newlist.get(i)).isEmpty())){
			newValue = identifiedName.get(newlist.get(i));
		}
		else{
			newValue = newlist.get(i);
		}
		
		
		System.out.println(newValue);
		switch (new_Value.toLowerCase()) {
		case "text":
			writer.write("\n\n" );
			writer.write("\r\n public void enter_" + newValue + "(String temp_" + newValue + "){ \n \n enterInputText(" + newValue+ ",temp_" + newValue + ",\"" + newValue.replace("_", " ") + "\"); \n } ");
			break;
			
		case "select":
			writer.write("\n\n" );
			writer.write("\r\n public void select_" + newValue + "(String temp_" + newValue + "){ \n \n selectVisibileText(" + newValue+ ",temp_" + newValue + ",\"" + newValue.replace("_", " ") + "\"); \n } ");
			break;	
			
		case "button":
			writer.write("\n\n" );
			writer.write("\r\n public void click_" + newValue + "(){ \n \n webElementClick(" + newValue+ ",\"" + newValue.replace("_", " ") + "\"); \n } ");
			break;	
		case "radio":
			writer.write("\n\n" );
			writer.write("\r\n public void select_" + newValue + "(String temp_" + newValue + "){ \n \n selectRadioButton(" + newValue+ ", temp_" + newValue + ",\""  + newValue.replace("_", " ") + "\"); \n } ");	
			break;
			
		case "link":
			writer.write("\n\n" );
			writer.write("\r\n public void click_" + newValue + "(){ \n \n webElementClick(" + newValue+ ",\"" + newValue.replace("_", " ") + "\"); \n } ");
			break;
			
		/*case "CheckBox":
			writer.write("//Skeleton code for new object" + newValue + "\n\n" );
			writer.write("ieButtonJSClick(ob." + newValue + ");\n");	
			writer.write("webElementClick(ob." + newValue + ");\n\n");
			break;	*/
			
				
		/*case "Link":
			writer.write("//Skeleton code for new object " + newValue + "\n\n" );
			writer.write("ieButtonJSClick(ob." + newValue + ");\n");	
			writer.write("webElementClick(ob." + newValue + ");\n");
			writer.write("getTextFromWebElement(ob."+ newValue +");\n\n");
			break;*/

		default:
			break;		
		
		}
		
		
	}
	
	writer.write("\n}\n");
    writer.close();
	
	
    
}




}
