package TechMQA;

public class SBI extends RBI {

	public void rule(int amt) {
		if(amt > 25000) {
			System.out.println("amount limit crossed 25000");
		}
		
	}
	
}
