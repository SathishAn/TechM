package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;

import TechMQA.ExcelWriter;
import utilities.CoreTapWrappers;

public class T24_CorporateCustomerPage extends CoreTapWrappers{
	public T24_CorporateCustomerPage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.test = test;
		PageFactory.initElements(this.driver, this);
		if (!verifyTitle("CUSTOMER")) {
			reportStep("This is not a customer Page", "FAIL");
		}
		driver.manage().window().maximize();
	}
	
	public void inputData(WebElement ele, String data, String fieldName) {
		try {			
			ele.clear();
			ele.sendKeys(data);
			System.out.println( fieldName +" Entered with value " + data + "successfully");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("some error occured" + e.getMessage());
		}
	}
	
	public void call_ObjectExtractor() {
		WebElement ele;
		 ele = driver.findElement(By.id("firstName"));
		inputData(ele, "Sathish", "First Name");
		
		ele = driver.findElement(By.id("FamilyName"));
		inputData(ele, "Anabalagan", "Family Name");
		
		
		ele = driver.findElement(By.id("Short Name"));
		inputData(ele, "SAT", "Short Name");
		
		
		
		
		ExcelWriter excel= new ExcelWriter(driver);
		try {
			excel.designAccelator("T24_CorporateCustomerPage");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
