package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;

import utilities.CoreTapWrappers;

public class T24_HomePage  extends CoreTapWrappers {
	

	public T24_HomePage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.test = test;
		PageFactory.initElements(this.driver, this);
		/*if (!verifyTitle("Sat")) {
			reportStep("This is not Page", "FAIL");
		}*/
	}
	
	
	@FindBy(how=How.XPATH, using="//frame[contains(@id,'menu')]") WebElement Hompageframe;
	
	@FindBy(how=How.XPATH, using="//span[text()='User Menu']") WebElement userMenu;
	
	@FindBy(how=How.XPATH, using="//span[text()='Customer']") WebElement customerMenu;
	
	@FindBy(how=How.LINK_TEXT, using="Individual Customer") WebElement individualCustomerMenu;
	
	@FindBy(how=How.LINK_TEXT, using="Corporate Customer") WebElement corporateCustomerMenu;
	
	@FindBy(how=How.LINK_TEXT, using="Authorise/Delete Customer") WebElement AuthoriseCustomerMenu;
	
	public void switchFrame() {
		driver.switchTo().frame(Hompageframe);
		
	}
	
	public void click_UserMenu() {
		webElementClick(userMenu, "User Menu");
	}
	
	public void click_CustomerMenu() {
		webElementClick(customerMenu, "Customer Menu");
	}
	
	public void click_IndividualCustomerMenu() {
		webElementClick(individualCustomerMenu, "Individual Customer Menu");
		driver.switchTo().defaultContent();
		switchToLastWindow();
	}
	
	public void click_AuthoriseCustomerMenu() {
		webElementClick(AuthoriseCustomerMenu, "Authorise Customer Menu");
		driver.switchTo().defaultContent();
		switchToLastWindow();
	}
	
	public void click_corporateCustomerMenu() {
		webElementClick(corporateCustomerMenu, "Corporate Customer Menu");
		driver.switchTo().defaultContent();
		switchToLastWindow();
	}
	
	
	
}
