package stepdefinitions;

import java.io.IOException;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;

import com.codoid.products.exception.FilloException;
import com.relevantcodes.extentreports.ExtentTest;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;


import techM.TechMRunnerClass;
import utilities.CoreTapWrappers;
import utilities.DataProvider;

public class BaseTestSetup_Glue extends CoreTapWrappers {
	DataProvider dataprovider = new DataProvider();
	
	
	@Before
    public void beforeCucumber(Scenario scenario) {
    	System.out.println("Before Scenario");
    	this.scenario = scenario; 
    	System.out.println("###########################################");
    	System.out.println(scenario.getName());
    	StringBuffer scenarioName = new StringBuffer();
    	StringBuffer testcaseName = new StringBuffer();
    	StringBuffer sheetName = new StringBuffer();
    	scenarioName.append(scenario.getName());
    	testcaseName.append(scenarioName.substring(scenarioName.indexOf("|~")+2, scenarioName.indexOf("|@")).trim().replace("\"", ""));
    	sheetName.append(scenarioName.substring(scenarioName.indexOf("|@")+2).trim().replace("\"", ""));
    	excelHashMapValues.put("scenarioName", testcaseName.toString());
    	excelHashMapValues.put("sheetName", sheetName.toString());
    	System.out.println(excelHashMapValues.get("scenarioName") + "  -- " + excelHashMapValues.get("sheetName"));
    	try {
			dataprovider.extractExcelData(testcaseName.toString(), sheetName.toString(), excelHashMapValues);
		} catch (FilloException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}    	
    	
    	
    	if(excelHashMapValues.get("ExecutionFlag").equals("Y")) {
    		
			test = startTestCase(testcaseName.toString(), scenarioName.toString().substring(0,scenarioName.indexOf("|")));
	    	System.out.println("###########################################End");
    	}else {
    		throw new SkipException("Test skipped");
    	}
    	
    }
	
	 
	 
	 

	
	
	@After
	public void testAfter() {
		if(excelHashMapValues.get("ExecutionFlag").equals("Y")) {
			System.out.println("After Scenario");
	    	endTestcase();
	    	//closeAllBrowsers();
		}
	}
	
}
