package stepdefinitions;

import org.openqa.selenium.By;

import pages.T24_CorporateCustomerPage;
import utilities.CoreTapWrappers;

public class T24_CorporateCustomer_Glue extends CoreTapWrappers {
T24_CorporateCustomerPage corporateCust= new T24_CorporateCustomerPage(driver, test);
	
	
	
	
}
