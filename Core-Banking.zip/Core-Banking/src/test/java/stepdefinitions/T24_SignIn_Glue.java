package stepdefinitions;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pages.T24_HomePage;
import pages.T24_IndividualCustomerPage;
import pages.T24_SignInPage;
import pages.T24_UnAuthorisedCustomerPage;
import utilities.CoreTapWrappers;

public class T24_SignIn_Glue extends CoreTapWrappers {
	
	@Given("^Launch the \"([^\"]*)\" appliaction$")
	public void launch_the_Application(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	  invokeApp("Chrome", config.getPropertyValue(arg1));
	   
	}  
	
	@Then("^Home page should be navigate$")
	public void home_page_should_be_navigate() {
		captureScreenshot("HomePage Navigation");
	}
	
	@When("^navigate to \"([^\"]*)\" under the user menu$")
	public void i_enter_the_Mandate_details_in_the_application(String tempValue) throws Throwable {
	   
		T24_HomePage homePage = new T24_HomePage(driver, test);
		homePage.switchFrame();
		homePage.click_UserMenu();
		homePage.click_CustomerMenu();
		switch (tempValue.toLowerCase()) {
		case "individual customer":			
			homePage.click_IndividualCustomerMenu();
			break;
			
		case "corporate customer":
			homePage.click_IndividualCustomerMenu();			
			break;
			
		case "authorise customer":			
			homePage.click_corporateCustomerMenu();
			break;
			
		default:
			break;
		} 
	   
	}
	
	@When("^I sign in with \"([^\"]*)\" user$")
	public void i_sign_in_with_user(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		T24_SignInPage signon= new T24_SignInPage(driver, test);
		signon.enterUserName(config.getPropertyValue(arg1));
		signon.enterPassword(config.getPropertyValue(arg1+"_PWD"));
		captureScreenshot("Login");
		signon.clickSignIn();
		
	}

}
