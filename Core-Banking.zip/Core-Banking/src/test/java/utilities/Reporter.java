package utilities;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Optional;

import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public abstract class Reporter {
	public static ExtentTest test;
	public static ExtentReports extent;
	public static String testCaseName, testDescription, category, authors, reportPath;
	
	public void startReporter() {
			SimpleDateFormat formatdate = new SimpleDateFormat("dd-MM-YYYY_HH-mm-ss");
			java.util.Date date = new java.util.Date();
			String newDate = formatdate.format(date).toString();
			System.out.println(newDate);
			reportPath = "./reports/"+newDate;
			 File directory = new File(reportPath);
		  		if (!directory.exists()) {
		  			directory.mkdirs();
		  		}
		
	}
	
	public void reportStep(String desc, String status) {
		
		// Write if it is successful or failure or information
 		System.out.println(reportPath);
		if(status.toUpperCase().equals("PASS")){
			test.log(LogStatus.PASS, desc);
		}else if(status.toUpperCase().equals("FAIL")){
			test.log(LogStatus.FAIL, desc);			
		}else if(status.toUpperCase().equals("INFO")){
			long snapNumber = 100000l;
			
			try {			
					snapNumber= takeSnap();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			test.log(LogStatus.INFO, desc + test.addScreenCapture("./../."+reportPath +"/images/"+snapNumber+".jpg"));
		}
	}

	
	public void reportStep(String desc, String status, boolean screenFlag) {
		
		
		long snapNumber = 100000l;
		
		try {	
				if (screenFlag){
				snapNumber= takeSnap();
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Write if it is successful or failure or information
		if(status.toUpperCase().equals("PASS")){
			test.log(LogStatus.PASS, desc);
		}else if(status.toUpperCase().equals("FAIL")){
			test.log(LogStatus.FAIL, desc);
			
		}else if(status.toUpperCase().equals("INFO")){
			test.log(LogStatus.INFO, desc);
		}
	}

	public abstract long takeSnap();
	

	public ExtentReports startResult(){
		startReporter();
		extent = new ExtentReports(reportPath +"/result.html", false);
		extent.loadConfig(new File("./src/test/resources/extent-config.xml"));
		return extent;
	}

	public ExtentTest startTestCase(String testCaseName, String testDescription){
		test = extent.startTest(testCaseName, testDescription);
		return test;
	}

	public void endResult(){		
		extent.flush();
	}

	public void endTestcase(){
		extent.endTest(test);
	}
	
	public void sampleCoreTest() {
		test = extent.startTest("", "");
		extent.endTest(test);
	}




	
	
}
