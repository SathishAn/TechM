package TechMQA;

import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentTest;

public class Controller {
	private WebDriver driver;
	private ExtentTest test;
	 
	 public Controller(){
		 	
	 }
	
}
