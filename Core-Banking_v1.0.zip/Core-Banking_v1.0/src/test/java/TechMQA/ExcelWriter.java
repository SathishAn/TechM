package TechMQA;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.validator.GenericTypeValidator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ExcelWriter {
	static int newFlag = 0;
	static XSSFWorkbook wwb;
	static Sheet sheet;
	static File filePath;
	static String id, name, className, xpath, fieldValue, fieldText;
	
	private static WebDriver driver;

	public ExcelWriter(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	public static String updateValues(WebElement element, String fieldType) {
		id = element.getAttribute("id");
		name = element.getAttribute("name");
		className = element.getAttribute("class");
		fieldValue = element.getText();
		String xpath = "";
		String sTempValue = "";
		if (!id.isEmpty()) {
			if (id.contains("fieldName:")) {
				sTempValue = id.replace("CheckBox:", "");
				sTempValue = id.replace("fieldName:", "fieldCaption:");
				sTempValue = sTempValue.replaceAll(":\\d", "");
				System.out.println(sTempValue);
				List<WebElement> ele = driver.findElements(By.id(sTempValue));
				if (ele.size() > 0) {
					String script = "return arguments[0].innerHTML";
					fieldText = (String) ((JavascriptExecutor) driver).executeScript(script, ele.get(0));					

				} else {
					fieldText = sTempValue.replaceAll("fieldCaption:", "");
				}
			} else if (id.contains("radio")) {
				sTempValue = id.replace("radio:tab\\d:", "fieldCaption:");
				sTempValue = id.replace("radio:mainTab:", "fieldCaption:");
				sTempValue = sTempValue.replaceAll(":\\d", "");
				System.out.println(sTempValue);
				List<WebElement> ele = driver.findElements(By.id(sTempValue));
				if (ele.size() > 0) {
					String script = "return arguments[0].innerHTML";
					fieldText = (String) ((JavascriptExecutor) driver).executeScript(script, ele.get(0));
				} else {
					fieldText = sTempValue.replaceAll("fieldCaption:", "");
				}

			} else {
				fieldText = id;
			}

		}

		xpath = "";
		// FieldText = id;
		dataUpdateWorkbook(fieldText, fieldType, id, name, className, "", "", "", "", "", xpath);
		return fieldText;
	}

	public static void updateLinkValues(WebElement element, String fieldType) {

		fieldValue = element.getText();
		String xpath = "";
		xpath = "";
		// FieldText = id;
		dataUpdateWorkbook(fieldText, fieldType, id, name, className, "", "", "", "", "", xpath);
	}

	public static void designAccelator(String pageName) throws Exception {

		filePath = new File("./src/test/resources/Datatable/accelator.xlsx");
		if (!filePath.exists() || newFlag == 0) {
			createWorkbook();
			newFlag = 1;
		}
		headerUpdateWorkbook();

		java.util.List<org.openqa.selenium.WebElement> linkElements3 = driver.findElements(By.tagName("select"));
		for (int i = 0; i < linkElements3.size(); i++) {
			System.out.println(i + "select size");
			

		}

		java.util.List<org.openqa.selenium.WebElement> linkElements5 = driver.findElements(By.tagName("button"));
		for (int i = 0; i < linkElements5.size(); i++) {
			System.out.println(i + "button size");
			updateValues(linkElements5.get(i), "Button");

		}

		java.util.List<org.openqa.selenium.WebElement> linkElements6 = driver.findElements(By.tagName("a"));
		for (int i = 0; i < linkElements6.size(); i++) {
			if (linkElements6.get(i).getAttribute("class").contains("nonactive-tab")) {
				fieldValue = linkElements6.get(i).getText();
				// FieldText = id;
				dataUpdateWorkbook(fieldValue, "Link", "", "", "", "", "", "", "", fieldValue, "");
			}

		}

		java.util.List<org.openqa.selenium.WebElement> linkElements = driver.findElements(By.tagName("input"));
		for (int i = 0; i < linkElements.size(); i++) {
			if (linkElements.get(i).getAttribute("type").equals("text")) {
				System.out.println("*************************Input Type Text **********************");
				updateValues(linkElements.get(i), "Text");

			} else if (!linkElements.get(i).getAttribute("type").equals("")
					& linkElements.get(i).getAttribute("type").equals("button")) {

				updateValues(linkElements.get(i), "Button");

			} else if (!linkElements.get(i).getAttribute("type").equals("")
					& linkElements.get(i).getAttribute("type").equals("radio")) {
				System.out.println("Input Type Rado");
				updateValues(linkElements.get(i), "Radio");

			} else if (!linkElements.get(i).getAttribute("type").equals("")
					& linkElements.get(i).getAttribute("type").equals("checkbox")) {
				System.out.println("Input Type Checkbox");
				updateValues(linkElements.get(i), "CheckBox");
			} else if (!linkElements.get(i).getAttribute("type").equals("")
					& linkElements.get(i).getAttribute("type").equals("submit")) {
				updateValues(linkElements.get(i), "submit");

			} else if (!linkElements.get(i).getAttribute("type").equals("text")
					& linkElements.get(i).getAttribute("value").equals("select")) {
				updateValues(linkElements.get(i), "select");

			}

		}

		ReadObject.createPageFactory(pageName);

	}

	// Create a new Workbook
	public static void createWorkbook() {
		FileOutputStream outStream;
		try {
			System.out.println("Create Workbook");
			outStream = new FileOutputStream(filePath);
			wwb = new XSSFWorkbook();
			sheet = wwb.createSheet("PSTC");
			wwb.write(outStream);
			outStream.close();

		} catch (Exception e) { // TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void headerUpdateWorkbook() throws IOException {
		FileInputStream inputstreams = new FileInputStream(filePath);
		wwb = new XSSFWorkbook(inputstreams);
		sheet = wwb.getSheetAt(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println(rowCount);

		if (rowCount < 1) {

			Row row = sheet.createRow(0);
			row.createCell(0).setCellValue("Field_Text");
			row.createCell(1).setCellValue("Field_Type");
			row.createCell(2).setCellValue("Attribute_ID");
			row.createCell(3).setCellValue("Attribute_Name");
			row.createCell(4).setCellValue("Attribute_InnerText");
			row.createCell(5).setCellValue("Attribute_Class");
			row.createCell(6).setCellValue("Attribute_Value");
			row.createCell(7).setCellValue("Attribute_Placeholder");
			row.createCell(8).setCellValue("Attribute_Title");
			row.createCell(9).setCellValue("Attribute_TextValue");
			row.createCell(10).setCellValue("Attribute_xpath");

		}

		inputstreams.close();
		FileOutputStream outStream = new FileOutputStream(filePath);
		wwb.write(outStream);
		outStream.close();

	}

	public static void dataUpdateWorkbook(String sf1, String sf2, String sf3, String sf4, String sf5, String sf6,
			String sf7, String sf8, String sf9, String sf10, String sf11) {
		System.out.println("Sample");
		FileInputStream inputstreams = null;
		try {
			inputstreams = new FileInputStream(filePath);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			wwb = new XSSFWorkbook(inputstreams);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sheet = wwb.getSheetAt(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println(rowCount);
		if ((sf1 == null || sf1.equals("") || sf1.equals("null")) && !(sf3.equals(""))) {
			sf1 = sf3;
		} else if ((sf1 == null || sf1.equals("") || sf1.equals("null")) && !(sf4.equals(""))) {
			sf1 = sf4;
		}
		if (!sf11.contains("//")) {
			sf11 = "";
		}

		Row row = sheet.createRow(rowCount + 1);
		System.out.println(sf1);
		sf1 = sf1.replace("fieldName:", "").trim();
		sf1 = sf1.replace(":", "_").trim().replaceAll("\\W", "").trim();
		// sf1 = sf1.replace(".", "_").trim().replaceAll("/", "_");
		row.createCell(0).setCellValue(sf1.replaceAll(" ", "_").trim());
		row.createCell(1).setCellValue(sf2);
		row.createCell(2).setCellValue(sf3);
		row.createCell(3).setCellValue(sf4);
		row.createCell(4).setCellValue(sf5);
		row.createCell(5).setCellValue(sf6);
		row.createCell(6).setCellValue(sf7);
		row.createCell(7).setCellValue(sf8);
		row.createCell(8).setCellValue(sf9);
		row.createCell(9).setCellValue(sf10);
		row.createCell(10).setCellValue(sf11);

		try {
			inputstreams.close();
			FileOutputStream outStream = new FileOutputStream(filePath);
			wwb.write(outStream);
			outStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String identifyObject(String xPathValue) {
		String attribute, label, value = null, fieldText = null;
		attribute = getValue(xPathValue, "Attribute");
		System.out.println(attribute);
		label = getValue(xPathValue, "Label");
		System.out.println(label);
		value = getValue(xPathValue, "Value");
		System.out.println(value);
		String xValue = generateXpath(attribute, label, value);
		System.out.println(xValue);

		return xValue;

	}

	public static String xpathGenerator(WebElement linkElements, String type) throws InterruptedException {

		// TODO Auto-generated method stub
		int identifiedFlag = 0;
		String newXpath = null, tagName;
		tagName = linkElements.getTagName();
		System.out.println("------" + tagName);
		String[] strFlow = { "Preceding", "Parent", "Parent_sibling", "Parent_sib_child", "Grand_Parent",
				"Grand_Parent_sibling" };
		tagName = linkElements.getTagName();
		if (tagName.equals("input")) {
			newXpath = tagName + "[@type='" + type + "']";
		} else {
			newXpath = tagName;
		}
		identifiedFlag = 0;
		String xPathValue;

		List<WebElement> preceding, Parent_Sibling, Grand_Parent_Sibling;
		WebElement Parents = null, Grand_Parents = null;
		int iCount = 0;
		do {
			System.out.println("###################################################################");
			switch (strFlow[iCount]) {
			case "Preceding":
				preceding = linkElements.findElements(By.xpath("preceding-sibling::*"));
				System.out.println(preceding.size());
				if (preceding.size() > 0) {
					System.out.println("Entering into precedeing");
					xPathValue = findElementsTag(preceding);
					if (xPathValue != null) {
						String xValue = identifyObject(xPathValue);
						newXpath = xValue + "/following-sibling::" + newXpath;
						identifiedFlag = 1;
						System.out.println(newXpath);
					}
				}
				break;
			case "Parent":
				Parents = linkElements.findElement(By.xpath("parent::*"));
				tagName = Parents.getTagName();
				System.out.println("Entering into parents " + tagName);
				xPathValue = findParentTag(Parents, type);
				if (xPathValue != null) {
					String xValue = identifyObject(xPathValue);
					newXpath = xValue + "/" + newXpath;
					identifiedFlag = 1;
					System.out.println(newXpath);
				} else {
					newXpath = tagName + "/" + newXpath;
				}
				break;
			case "Parent_sibling":
				Parent_Sibling = Parents.findElements(By.xpath("preceding-sibling::*"));
				if (Parent_Sibling.size() > 0) {
					System.out.println("Entering into Parent precedeing");
					xPathValue = findElementsTag(Parent_Sibling);
					System.out.println(xPathValue);
					if (xPathValue != null) {
						String xValue = identifyObject(xPathValue);
						newXpath = xValue + "/following-sibling::" + newXpath;
						identifiedFlag = 1;
						System.out.println(newXpath);
					}
				}
				break;
			case "Grand_Parent":
				Grand_Parents = Parents.findElement(By.xpath("parent::*"));
				tagName = Grand_Parents.getTagName();
				System.out.println("Entering into Grand parents " + tagName);
				xPathValue = findParentTag(Grand_Parents, type);
				if (xPathValue != null) {
					String xValue = identifyObject(xPathValue);
					newXpath = xValue + "/" + newXpath;
					identifiedFlag = 1;
					System.out.println(newXpath);
				} else {
					newXpath = tagName + "/" + newXpath;
				}
				break;
			case "Grand_Parent_sibling":
				Grand_Parent_Sibling = Grand_Parents.findElements(By.xpath("preceding-sibling::*[1]"));
				if (Grand_Parent_Sibling.size() > 0) {
					System.out.println("Entering into Grand Parent precedeing");
					xPathValue = findElementsTag(Grand_Parent_Sibling);
					System.out.println(xPathValue);
					if (xPathValue != null) {
						String xValue = identifyObject(xPathValue);
						newXpath = xValue + "following-sibling::" + newXpath;
						identifiedFlag = 1;
						System.out.println(newXpath);
					} else {

						List<WebElement> child = Grand_Parent_Sibling.get(0).findElements(By.xpath("descendant::*"));
						System.out.println(child.size());
						if (child.size() > 0) {
							System.out.println("Entering into Descendant");
							xPathValue = FindChlidElementTag(child);
							System.out.println(xPathValue);
							if (xPathValue != null) {
								String xValue = identifyObject(xPathValue);
								newXpath = xValue + "/../following-sibling::" + newXpath;
								System.out.println(newXpath);
								identifiedFlag = 1;
							}
						}
					}
				}
				break;
			default:
				break;
			}
			iCount++;

		} while (identifiedFlag == 0 & iCount < strFlow.length);
		if (fieldText != null) {
			if (fieldText.length() > 25) {
				if (fieldText.indexOf("\n") > 0) {
					fieldText = fieldText.substring(0, fieldText.indexOf("\n"));
				} else {
					fieldText = fieldText.substring(0, 25);
				}
			}
		}

		return newXpath + "~$" + fieldText;

	}

	public static String FindChlidElementTag(List<WebElement> element) {

		String tagName = null;
		System.out.println(element.get(0).getTagName());
		System.out.println(element.get(0).getText());
		for (int j = 0; j < element.size(); j++) {
			System.out.println(element.get(j).getTagName());
			if (element.get(j).getAttribute("for") != null) {
				tagName = "FOR" + "~#" + element.get(j).getTagName() + "~*" + element.get(j).getAttribute("for") + "~$"
						+ element.get(j).getText();
				break;
			} else if (!element.get(j).getText().equals("")) {
				System.out.println(element.get(j).getTagName());
				tagName = "Text-decendent" + "~#" + element.get(j).getTagName() + "~*" + element.get(j).getText() + "~$"
						+ element.get(j).getText();
				break;
			}
		}
		return tagName;

	}

	public static String findElementsTag(List<WebElement> element) {
		String tagName = null;
		System.out.println(element.get(0).getTagName());
		for (int j = 0; j < element.size(); j++) {
			System.out.println(element.get(j).getTagName());
			if (element.get(j).getAttribute("for") != null) {
				tagName = "FOR" + "~#" + element.get(j).getTagName() + "~*" + element.get(j).getAttribute("for") + "~$"
						+ element.get(j).getText();
				break;
			} else if (!element.get(j).getText().equals("")) {
				System.out.println(element.get(j).getTagName());
				List<WebElement> childElements = element.get(j).findElements(By.xpath("descendant::*"));
				if (childElements.size() > 0) {

				} else {
					tagName = "Text-decendent" + "~#" + element.get(j).getTagName() + "~*" + element.get(j).getText()
							+ "~$";
				}

				break;

			}

		}
		return tagName;

	}

	public static String findParentTag(WebElement element, String type) {
		String tagName = null;

		System.out.println(element.getTagName() + " - " + element.getText());
		if (element.getAttribute("for") != null) {
			tagName = "FOR" + "~#" + element.getTagName() + "~*" + element.getAttribute("for") + "~$";
			System.out.println(element.getText());
		} else if (!element.getText().equals("") && !(type.equals("select"))) {
			System.out.println(element.findElement(By.xpath("descendant::*")).getTagName());

			List<WebElement> childElements = element.findElements(By.xpath("descendant::*"));
			if (childElements.size() > 0) {
				for (int i = 0; i < childElements.size(); i++) {
					if (childElements.get(i).getText() != null & !(childElements.get(i).getText().equals(""))) {
						tagName = "Text-decendent" + "~#" + childElements.get(i).getTagName() + "~*"
								+ childElements.get(i).getText() + "~$";
						break;
					}
				}
			} else {
				tagName = "Text" + "~#" + element.getTagName() + "~*" + element.getText();
			}

		}

		return tagName;

	}

	public static String generateXpath(String attribute, String label, String value) {
		String xpathValue = null;
		value = value.replace("*", "");
		switch (attribute) {
		case "FOR":
			xpathValue = "//" + label + "[@for='" + value + "']";
			break;
		case "Text":
			if (value.length() > 30) {
				if (value.indexOf("\n") > 0) {
					value = value.substring(0, value.indexOf("\n"));
				} else {
					value = value.substring(0, 30);
				}
				xpathValue = "//" + label + "[contains(text(), '" + value + "')]/..";
			} else {
				xpathValue = "//" + label + "[text()= '" + value + "']/..";

			}
			break;

		case "Text-decendent":
			if (value.length() > 30) {
				if (value.indexOf("\n") > 0) {
					value = value.substring(0, value.indexOf("\n"));
				} else {
					value = value.substring(0, 30);
				}

				xpathValue = "//" + label + "[contains(text(), '" + value + "')]/";
			} else {
				xpathValue = "//" + label + "[text()= '" + value + "']/";

			}
			break;

		default:
			break;
		}

		return xpathValue;

	}

	public static String getValue(String value, String valueType) {
		String tempValue = null;
		switch (valueType) {
		case "Attribute":
			tempValue = value.substring(0, value.indexOf("~#"));
			break;
		case "Label":
			tempValue = value.substring(value.indexOf("~#") + 2, value.indexOf("~*"));
			break;

		case "Value":
			tempValue = value.substring(value.indexOf("~*") + 2, value.indexOf("~$"));
			break;

		case "Field Text":
			tempValue = value.substring(value.indexOf("~$") + 2);
		default:
			break;
		}

		return tempValue;

	}

}
