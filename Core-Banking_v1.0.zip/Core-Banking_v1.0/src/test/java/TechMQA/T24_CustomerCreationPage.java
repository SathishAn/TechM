package TechMQA;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utilities.CoreTapWrappers;
import org.openqa.selenium.support.How;

public class T24_CustomerCreationPage extends CoreTapWrappers {


 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:AML.RESULT") WebElement AMLResult;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ACCOUNT.OFFICER") WebElement AccountOfficer;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ANNUAL.BONUS:1") WebElement AnnualBonus1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Audit") WebElement Audit;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:AUTO.NEXT.KYC.REVIEW.DATE") WebElement AutoNextKYCRev;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:AUTO.NEXT.SUIT.REVIEW.DATE") WebElement AutoNextSuitRev;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:COMPANY.BOOK") WebElement BranchName;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ALLOW.BULK.PROCESS") WebElement BulkPaymentRequired;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CALC.RISK.CLASS") WebElement CalcRiskClass;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CHANGE.DATE:1") WebElement ChangeDate1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CHANGE.REASON:1") WebElement ChangeReason1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "CheckBox:fieldName:SECURE.MESSAGE") WebElement CheckBox_SECUREMESSAGE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "CheckBox:fieldName:UPDATE.PREV.ADDRESS") WebElement CheckBox_UPDATEPREVADDRESS;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:COMM.TYPE:1") WebElement CommType1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Communication Details") WebElement CommunicationDetails;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CONTACT.DATE") WebElement ContactDate;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CR.CALC.RESET.DATE:1") WebElement CrCalcRestDate1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CR.USER.PROFILE:1") WebElement CrUserProfile1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CR.USER.PROFILE.TYPE:1") WebElement CrUserProfileType1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CUSTOMER.CURRENCY:1") WebElement CustomerCurrency1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CUSTOMER.LIABILITY") WebElement CustomerLiability;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CUSTOMER.RATING:1") WebElement CustomerRating1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:SALARY:1") WebElement CustomerSalary1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CUSTOMER.SINCE") WebElement CustomerSince;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CUSTOMER.STATUS") WebElement CustomerStatus;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:CUSTOMER.TYPE") WebElement CustomerType;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:DATE.OF.BIRTH") WebElement DateofBirth;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LEGAL.DOC.NAME:1") WebElement DocumentName1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:EMAIL.1:1") WebElement EmailAddress1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:EMPLOYERS.ADD:1:1") WebElement EmployersAddress11;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:EMPLOYERS.BUSS:1") WebElement EmployersBusiness1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:EMPLOYERS.NAME:1") WebElement EmployersName1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:EMPLOYMENT.START:1") WebElement EmploymentStartDt1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:EMPLOYMENT.STATUS:1") WebElement EmploymentStatus1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LEGAL.EXP.DATE:1") WebElement ExpirationDate1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:FAMILY.NAME") WebElement FAMILYNAME;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:FAX.1:1") WebElement Fax1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Financial Details") WebElement FinancialDetails;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Further Details") WebElement FurtherDetails;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ADDRESS:1:1") WebElement GBAddress1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:COUNTRY:1") WebElement GBCountry;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:NAME.1:1") WebElement GBFullName;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:NAME.2:1") WebElement GBFullName2;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:POST.CODE:1") WebElement GBPostCode;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:SHORT.NAME:1") WebElement GBShortName;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:STREET:1") WebElement GBStreet;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:TOWN.COUNTRY:1") WebElement GBTownCity;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:GIVEN.NAMES") WebElement GIVENNAMES;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:mainTab:GENDER") List<WebElement> Gender;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:HOLDINGS.PIVOT:1") WebElement HoldingsPivot1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "ID Doc") WebElement IDDoc;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:INDUSTRY") WebElement Industry;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:INTERESTS:1") WebElement Interests1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:INTRODUCER") WebElement Introducer;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LEGAL.ISS.AUTH:1") WebElement IssueAuthority1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ISSUE.CHEQUES") WebElement IssueCheque;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LEGAL.ISS.DATE:1") WebElement IssueDate1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:JOB.TITLE:1") WebElement JobTitle1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "KYC") WebElement KYC;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:KYC.RELATIONSHIP") WebElement KycRelationship;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LANGUAGE") WebElement Language;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LAST.AML.RESULT.DATE") WebElement LastAMLResultDt;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LAST.KYC.REVIEW.DATE") WebElement LastKYCReviewDate;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LAST.SUIT.REVIEW.DATE") WebElement LastSuitReviewDate;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LEGAL.ID:1") WebElement LegalID1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:MORTGAGE.AMT:1") WebElement MORTGAGEAMT;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:MANUAL.NEXT.KYC.REVIEW.DATE") WebElement ManualNextKYCRev;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:MANUAL.NEXT.SUIT.REVIEW.DATE") WebElement ManualNextSuitRev;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:MANUAL.RISK.CLASS") WebElement ManualRiskClass;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:MARITAL.STATUS") WebElement MaritalStatus;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:MNEMONIC") WebElement Mnemonic;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:SMS.1:1") WebElement MobilePhoneNumbers1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ROLE.MORE.INFO:1:1") WebElement MoreRoleInfo11;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:LEGAL.HOLDER.NAME:1") WebElement NameonID1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:NATIONALITY") WebElement Nationality;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:NET.MONTHLY.IN") WebElement NetMonthlyIn;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:NET.MONTHLY.OUT") WebElement NetMonthlyOut;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:NO.OF.DEPENDENTS") WebElement NoofDependents;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:OCCUPATION:1") WebElement Occupation1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Other Details") WebElement OtherDetails;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:OTHER.NATIONALITY:1") WebElement OtherNationality1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:OFF.PHONE:1") WebElement PhoneNumbersOff1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:PHONE.1:1") WebElement PhoneNumbersRes1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:PREF.CHANNEL:1") WebElement PrefChannel1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:PREVIOUS.NAME:1") WebElement PreviousName1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:FORMER.VIS.TYPE:1") WebElement PreviousVisibilityType1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:PROB.OF.DEFT:1") WebElement ProbabilityofDefault1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RESIDENCE.SINCE:1") WebElement RESIDENCESINCE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RESIDENCE.STATUS:1") WebElement RESIDENCESTATUS;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RESIDENCE.TYPE:1") WebElement RESIDENCETYPE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RESIDENCE.VALUE:1") WebElement RESIDENCEVALUE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Relation") WebElement Relation;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RELATION.CODE:1") WebElement RelationCode1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:REL.CUSTOMER:1") WebElement RelationCustomer1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:REL.DELIV.OPT:1:1") WebElement RelationDelvOption11;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Reporting Details") WebElement ReportingDetails;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RESIDENCE") WebElement Residence;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.LINK_TEXT, using= "Residential Details") WebElement ResidentialDetails;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RISK.ASSET.TYPE:1") WebElement RiskAssetType1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RISK.FROM.DATE:1") WebElement RiskFromDate1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RISK.LEVEL:1") WebElement RiskLevel1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:RISK.TOLERANCE:1") WebElement RiskTolerance1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ROLE:1:1") WebElement Role11;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:ROLE.NOTES:1:1") WebElement RoleNotes11;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:SALARY.DATE.FREQ:1") WebElement SalaryDateFreq1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:OTHER.OFFICER:1") WebElement SecondOfficer1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:SECTOR") WebElement Sector;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:SPOKEN.LANGUAGE:1") WebElement SpokenLanguage1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:TITLE") WebElement TITLE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:TARGET") WebElement Target;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:TAX.ID:1") WebElement TaxId1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:VIS.TYPE:1") WebElement VisibilityType1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "fieldName:VULNERABILITY:1") WebElement Vulnerability1;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "moreactions") WebElement moreactions;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab10:REPORT.TEMPLATE") List<WebElement> radio_tab10_REPORTTEMPLATE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab7:CONFID.TXT") List<WebElement> radio_tab7_CONFIDTXT;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab7:INTERNET.BANKING.SERVICE") List<WebElement> radio_tab7_INTERNETBANKINGSERVICE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab7:MOBILE.BANKING.SERVICE") List<WebElement> radio_tab7_MOBILEBANKINGSERVICE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab8:AML.CHECK") List<WebElement> radio_tab8_AMLCHECK;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab8:KYC.COMPLETE") List<WebElement> radio_tab8_KYCCOMPLETE;
 //New Object added - 13.08.2019 - 11.13.47

  @FindBy(how=How.ID, using= "radio:tab9:NO.UPDATE.CRM") List<WebElement> radio_tab9_NOUPDATECRM;


 public void select_AMLResult(String temp_AMLResult){ 
 
 selectVisibileText(AMLResult,temp_AMLResult,"AMLResult"); 
 } 


 public void enter_AccountOfficer(String temp_AccountOfficer){ 
 
 enterInputText(AccountOfficer,temp_AccountOfficer,"AccountOfficer"); 
 } 


 public void enter_AnnualBonus1(String temp_AnnualBonus1){ 
 
 enterInputText(AnnualBonus1,temp_AnnualBonus1,"AnnualBonus1"); 
 } 


 public void click_Audit(){ 
 
 webElementClick(Audit,"Audit"); 
 } 


 public void enter_AutoNextKYCRev(String temp_AutoNextKYCRev){ 
 
 enterInputText(AutoNextKYCRev,temp_AutoNextKYCRev,"AutoNextKYCRev"); 
 } 


 public void enter_AutoNextSuitRev(String temp_AutoNextSuitRev){ 
 
 enterInputText(AutoNextSuitRev,temp_AutoNextSuitRev,"AutoNextSuitRev"); 
 } 


 public void enter_BranchName(String temp_BranchName){ 
 
 enterInputText(BranchName,temp_BranchName,"BranchName"); 
 } 


 public void select_BulkPaymentRequired(String temp_BulkPaymentRequired){ 
 
 selectVisibileText(BulkPaymentRequired,temp_BulkPaymentRequired,"BulkPaymentRequired"); 
 } 


 public void enter_CalcRiskClass(String temp_CalcRiskClass){ 
 
 enterInputText(CalcRiskClass,temp_CalcRiskClass,"CalcRiskClass"); 
 } 


 public void enter_ChangeDate1(String temp_ChangeDate1){ 
 
 enterInputText(ChangeDate1,temp_ChangeDate1,"ChangeDate1"); 
 } 


 public void enter_ChangeReason1(String temp_ChangeReason1){ 
 
 enterInputText(ChangeReason1,temp_ChangeReason1,"ChangeReason1"); 
 } 


 public void select_CommType1(String temp_CommType1){ 
 
 selectVisibileText(CommType1,temp_CommType1,"CommType1"); 
 } 


 public void click_CommunicationDetails(){ 
 
 webElementClick(CommunicationDetails,"CommunicationDetails"); 
 } 


 public void enter_ContactDate(String temp_ContactDate){ 
 
 enterInputText(ContactDate,temp_ContactDate,"ContactDate"); 
 } 


 public void enter_CrCalcRestDate1(String temp_CrCalcRestDate1){ 
 
 enterInputText(CrCalcRestDate1,temp_CrCalcRestDate1,"CrCalcRestDate1"); 
 } 


 public void enter_CrUserProfile1(String temp_CrUserProfile1){ 
 
 enterInputText(CrUserProfile1,temp_CrUserProfile1,"CrUserProfile1"); 
 } 


 public void enter_CrUserProfileType1(String temp_CrUserProfileType1){ 
 
 enterInputText(CrUserProfileType1,temp_CrUserProfileType1,"CrUserProfileType1"); 
 } 


 public void enter_CustomerCurrency1(String temp_CustomerCurrency1){ 
 
 enterInputText(CustomerCurrency1,temp_CustomerCurrency1,"CustomerCurrency1"); 
 } 


 public void enter_CustomerLiability(String temp_CustomerLiability){ 
 
 enterInputText(CustomerLiability,temp_CustomerLiability,"CustomerLiability"); 
 } 


 public void enter_CustomerRating1(String temp_CustomerRating1){ 
 
 enterInputText(CustomerRating1,temp_CustomerRating1,"CustomerRating1"); 
 } 


 public void enter_CustomerSalary1(String temp_CustomerSalary1){ 
 
 enterInputText(CustomerSalary1,temp_CustomerSalary1,"CustomerSalary1"); 
 } 


 public void enter_CustomerSince(String temp_CustomerSince){ 
 
 enterInputText(CustomerSince,temp_CustomerSince,"CustomerSince"); 
 } 


 public void enter_CustomerStatus(String temp_CustomerStatus){ 
 
 enterInputText(CustomerStatus,temp_CustomerStatus,"CustomerStatus"); 
 } 


 public void select_CustomerType(String temp_CustomerType){ 
 
 selectVisibileText(CustomerType,temp_CustomerType,"CustomerType"); 
 } 


 public void enter_DateofBirth(String temp_DateofBirth){ 
 
 enterInputText(DateofBirth,temp_DateofBirth,"DateofBirth"); 
 } 


 public void select_DocumentName1(String temp_DocumentName1){ 
 
 selectVisibileText(DocumentName1,temp_DocumentName1,"DocumentName1"); 
 } 


 public void enter_EmailAddress1(String temp_EmailAddress1){ 
 
 enterInputText(EmailAddress1,temp_EmailAddress1,"EmailAddress1"); 
 } 


 public void enter_EmployersAddress11(String temp_EmployersAddress11){ 
 
 enterInputText(EmployersAddress11,temp_EmployersAddress11,"EmployersAddress11"); 
 } 


 public void enter_EmployersBusiness1(String temp_EmployersBusiness1){ 
 
 enterInputText(EmployersBusiness1,temp_EmployersBusiness1,"EmployersBusiness1"); 
 } 


 public void enter_EmployersName1(String temp_EmployersName1){ 
 
 enterInputText(EmployersName1,temp_EmployersName1,"EmployersName1"); 
 } 


 public void enter_EmploymentStartDt1(String temp_EmploymentStartDt1){ 
 
 enterInputText(EmploymentStartDt1,temp_EmploymentStartDt1,"EmploymentStartDt1"); 
 } 


 public void select_EmploymentStatus1(String temp_EmploymentStatus1){ 
 
 selectVisibileText(EmploymentStatus1,temp_EmploymentStatus1,"EmploymentStatus1"); 
 } 


 public void enter_ExpirationDate1(String temp_ExpirationDate1){ 
 
 enterInputText(ExpirationDate1,temp_ExpirationDate1,"ExpirationDate1"); 
 } 


 public void enter_FAMILYNAME(String temp_FAMILYNAME){ 
 
 enterInputText(FAMILYNAME,temp_FAMILYNAME,"FAMILYNAME"); 
 } 


 public void enter_Fax1(String temp_Fax1){ 
 
 enterInputText(Fax1,temp_Fax1,"Fax1"); 
 } 


 public void click_FinancialDetails(){ 
 
 webElementClick(FinancialDetails,"FinancialDetails"); 
 } 


 public void click_FurtherDetails(){ 
 
 webElementClick(FurtherDetails,"FurtherDetails"); 
 } 


 public void enter_GBAddress1(String temp_GBAddress1){ 
 
 enterInputText(GBAddress1,temp_GBAddress1,"GBAddress1"); 
 } 


 public void enter_GBCountry(String temp_GBCountry){ 
 
 enterInputText(GBCountry,temp_GBCountry,"GBCountry"); 
 } 


 public void enter_GBFullName(String temp_GBFullName){ 
 
 enterInputText(GBFullName,temp_GBFullName,"GBFullName"); 
 } 


 public void enter_GBFullName2(String temp_GBFullName2){ 
 
 enterInputText(GBFullName2,temp_GBFullName2,"GBFullName2"); 
 } 


 public void enter_GBPostCode(String temp_GBPostCode){ 
 
 enterInputText(GBPostCode,temp_GBPostCode,"GBPostCode"); 
 } 


 public void enter_GBShortName(String temp_GBShortName){ 
 
 enterInputText(GBShortName,temp_GBShortName,"GBShortName"); 
 } 


 public void enter_GBStreet(String temp_GBStreet){ 
 
 enterInputText(GBStreet,temp_GBStreet,"GBStreet"); 
 } 


 public void enter_GBTownCity(String temp_GBTownCity){ 
 
 enterInputText(GBTownCity,temp_GBTownCity,"GBTownCity"); 
 } 


 public void enter_GIVENNAMES(String temp_GIVENNAMES){ 
 
 enterInputText(GIVENNAMES,temp_GIVENNAMES,"GIVENNAMES"); 
 } 


 public void select_Gender(String temp_Gender){ 
 
 selectRadioButton(Gender, temp_Gender,"Gender"); 
 } 


 public void enter_HoldingsPivot1(String temp_HoldingsPivot1){ 
 
 enterInputText(HoldingsPivot1,temp_HoldingsPivot1,"HoldingsPivot1"); 
 } 


 public void click_IDDoc(){ 
 
 webElementClick(IDDoc,"IDDoc"); 
 } 


 public void enter_Industry(String temp_Industry){ 
 
 enterInputText(Industry,temp_Industry,"Industry"); 
 } 


 public void enter_Interests1(String temp_Interests1){ 
 
 enterInputText(Interests1,temp_Interests1,"Interests1"); 
 } 


 public void enter_Introducer(String temp_Introducer){ 
 
 enterInputText(Introducer,temp_Introducer,"Introducer"); 
 } 


 public void enter_IssueAuthority1(String temp_IssueAuthority1){ 
 
 enterInputText(IssueAuthority1,temp_IssueAuthority1,"IssueAuthority1"); 
 } 


 public void select_IssueCheque(String temp_IssueCheque){ 
 
 selectVisibileText(IssueCheque,temp_IssueCheque,"IssueCheque"); 
 } 


 public void enter_IssueDate1(String temp_IssueDate1){ 
 
 enterInputText(IssueDate1,temp_IssueDate1,"IssueDate1"); 
 } 


 public void enter_JobTitle1(String temp_JobTitle1){ 
 
 enterInputText(JobTitle1,temp_JobTitle1,"JobTitle1"); 
 } 


 public void click_KYC(){ 
 
 webElementClick(KYC,"KYC"); 
 } 


 public void enter_KycRelationship(String temp_KycRelationship){ 
 
 enterInputText(KycRelationship,temp_KycRelationship,"KycRelationship"); 
 } 


 public void enter_Language(String temp_Language){ 
 
 enterInputText(Language,temp_Language,"Language"); 
 } 


 public void enter_LastAMLResultDt(String temp_LastAMLResultDt){ 
 
 enterInputText(LastAMLResultDt,temp_LastAMLResultDt,"LastAMLResultDt"); 
 } 


 public void enter_LastKYCReviewDate(String temp_LastKYCReviewDate){ 
 
 enterInputText(LastKYCReviewDate,temp_LastKYCReviewDate,"LastKYCReviewDate"); 
 } 


 public void enter_LastSuitReviewDate(String temp_LastSuitReviewDate){ 
 
 enterInputText(LastSuitReviewDate,temp_LastSuitReviewDate,"LastSuitReviewDate"); 
 } 


 public void enter_LegalID1(String temp_LegalID1){ 
 
 enterInputText(LegalID1,temp_LegalID1,"LegalID1"); 
 } 


 public void enter_MORTGAGEAMT(String temp_MORTGAGEAMT){ 
 
 enterInputText(MORTGAGEAMT,temp_MORTGAGEAMT,"MORTGAGEAMT"); 
 } 


 public void enter_ManualNextKYCRev(String temp_ManualNextKYCRev){ 
 
 enterInputText(ManualNextKYCRev,temp_ManualNextKYCRev,"ManualNextKYCRev"); 
 } 


 public void enter_ManualNextSuitRev(String temp_ManualNextSuitRev){ 
 
 enterInputText(ManualNextSuitRev,temp_ManualNextSuitRev,"ManualNextSuitRev"); 
 } 


 public void enter_ManualRiskClass(String temp_ManualRiskClass){ 
 
 enterInputText(ManualRiskClass,temp_ManualRiskClass,"ManualRiskClass"); 
 } 


 public void select_MaritalStatus(String temp_MaritalStatus){ 
 
 selectVisibileText(MaritalStatus,temp_MaritalStatus,"MaritalStatus"); 
 } 


 public void enter_Mnemonic(String temp_Mnemonic){ 
 
 enterInputText(Mnemonic,temp_Mnemonic,"Mnemonic"); 
 } 


 public void enter_MobilePhoneNumbers1(String temp_MobilePhoneNumbers1){ 
 
 enterInputText(MobilePhoneNumbers1,temp_MobilePhoneNumbers1,"MobilePhoneNumbers1"); 
 } 


 public void enter_MoreRoleInfo11(String temp_MoreRoleInfo11){ 
 
 enterInputText(MoreRoleInfo11,temp_MoreRoleInfo11,"MoreRoleInfo11"); 
 } 


 public void enter_NameonID1(String temp_NameonID1){ 
 
 enterInputText(NameonID1,temp_NameonID1,"NameonID1"); 
 } 


 public void enter_Nationality(String temp_Nationality){ 
 
 enterInputText(Nationality,temp_Nationality,"Nationality"); 
 } 


 public void enter_NetMonthlyIn(String temp_NetMonthlyIn){ 
 
 enterInputText(NetMonthlyIn,temp_NetMonthlyIn,"NetMonthlyIn"); 
 } 


 public void enter_NetMonthlyOut(String temp_NetMonthlyOut){ 
 
 enterInputText(NetMonthlyOut,temp_NetMonthlyOut,"NetMonthlyOut"); 
 } 


 public void enter_NoofDependents(String temp_NoofDependents){ 
 
 enterInputText(NoofDependents,temp_NoofDependents,"NoofDependents"); 
 } 


 public void enter_Occupation1(String temp_Occupation1){ 
 
 enterInputText(Occupation1,temp_Occupation1,"Occupation1"); 
 } 


 public void click_OtherDetails(){ 
 
 webElementClick(OtherDetails,"OtherDetails"); 
 } 


 public void enter_OtherNationality1(String temp_OtherNationality1){ 
 
 enterInputText(OtherNationality1,temp_OtherNationality1,"OtherNationality1"); 
 } 


 public void enter_PhoneNumbersOff1(String temp_PhoneNumbersOff1){ 
 
 enterInputText(PhoneNumbersOff1,temp_PhoneNumbersOff1,"PhoneNumbersOff1"); 
 } 


 public void enter_PhoneNumbersRes1(String temp_PhoneNumbersRes1){ 
 
 enterInputText(PhoneNumbersRes1,temp_PhoneNumbersRes1,"PhoneNumbersRes1"); 
 } 


 public void enter_PrefChannel1(String temp_PrefChannel1){ 
 
 enterInputText(PrefChannel1,temp_PrefChannel1,"PrefChannel1"); 
 } 


 public void enter_PreviousName1(String temp_PreviousName1){ 
 
 enterInputText(PreviousName1,temp_PreviousName1,"PreviousName1"); 
 } 


 public void enter_PreviousVisibilityType1(String temp_PreviousVisibilityType1){ 
 
 enterInputText(PreviousVisibilityType1,temp_PreviousVisibilityType1,"PreviousVisibilityType1"); 
 } 


 public void enter_ProbabilityofDefault1(String temp_ProbabilityofDefault1){ 
 
 enterInputText(ProbabilityofDefault1,temp_ProbabilityofDefault1,"ProbabilityofDefault1"); 
 } 


 public void enter_RESIDENCESINCE(String temp_RESIDENCESINCE){ 
 
 enterInputText(RESIDENCESINCE,temp_RESIDENCESINCE,"RESIDENCESINCE"); 
 } 


 public void select_RESIDENCESTATUS(String temp_RESIDENCESTATUS){ 
 
 selectVisibileText(RESIDENCESTATUS,temp_RESIDENCESTATUS,"RESIDENCESTATUS"); 
 } 


 public void select_RESIDENCETYPE(String temp_RESIDENCETYPE){ 
 
 selectVisibileText(RESIDENCETYPE,temp_RESIDENCETYPE,"RESIDENCETYPE"); 
 } 


 public void enter_RESIDENCEVALUE(String temp_RESIDENCEVALUE){ 
 
 enterInputText(RESIDENCEVALUE,temp_RESIDENCEVALUE,"RESIDENCEVALUE"); 
 } 


 public void click_Relation(){ 
 
 webElementClick(Relation,"Relation"); 
 } 


 public void enter_RelationCode1(String temp_RelationCode1){ 
 
 enterInputText(RelationCode1,temp_RelationCode1,"RelationCode1"); 
 } 


 public void enter_RelationCustomer1(String temp_RelationCustomer1){ 
 
 enterInputText(RelationCustomer1,temp_RelationCustomer1,"RelationCustomer1"); 
 } 


 public void select_RelationDelvOption11(String temp_RelationDelvOption11){ 
 
 selectVisibileText(RelationDelvOption11,temp_RelationDelvOption11,"RelationDelvOption11"); 
 } 


 public void click_ReportingDetails(){ 
 
 webElementClick(ReportingDetails,"ReportingDetails"); 
 } 


 public void enter_Residence(String temp_Residence){ 
 
 enterInputText(Residence,temp_Residence,"Residence"); 
 } 


 public void click_ResidentialDetails(){ 
 
 webElementClick(ResidentialDetails,"ResidentialDetails"); 
 } 


 public void enter_RiskAssetType1(String temp_RiskAssetType1){ 
 
 enterInputText(RiskAssetType1,temp_RiskAssetType1,"RiskAssetType1"); 
 } 


 public void enter_RiskFromDate1(String temp_RiskFromDate1){ 
 
 enterInputText(RiskFromDate1,temp_RiskFromDate1,"RiskFromDate1"); 
 } 


 public void enter_RiskLevel1(String temp_RiskLevel1){ 
 
 enterInputText(RiskLevel1,temp_RiskLevel1,"RiskLevel1"); 
 } 


 public void enter_RiskTolerance1(String temp_RiskTolerance1){ 
 
 enterInputText(RiskTolerance1,temp_RiskTolerance1,"RiskTolerance1"); 
 } 


 public void enter_Role11(String temp_Role11){ 
 
 enterInputText(Role11,temp_Role11,"Role11"); 
 } 


 public void enter_RoleNotes11(String temp_RoleNotes11){ 
 
 enterInputText(RoleNotes11,temp_RoleNotes11,"RoleNotes11"); 
 } 


 public void enter_SalaryDateFreq1(String temp_SalaryDateFreq1){ 
 
 enterInputText(SalaryDateFreq1,temp_SalaryDateFreq1,"SalaryDateFreq1"); 
 } 


 public void enter_SecondOfficer1(String temp_SecondOfficer1){ 
 
 enterInputText(SecondOfficer1,temp_SecondOfficer1,"SecondOfficer1"); 
 } 


 public void enter_Sector(String temp_Sector){ 
 
 enterInputText(Sector,temp_Sector,"Sector"); 
 } 


 public void enter_SpokenLanguage1(String temp_SpokenLanguage1){ 
 
 enterInputText(SpokenLanguage1,temp_SpokenLanguage1,"SpokenLanguage1"); 
 } 


 public void select_TITLE(String temp_TITLE){ 
 
 selectVisibileText(TITLE,temp_TITLE,"TITLE"); 
 } 


 public void enter_Target(String temp_Target){ 
 
 enterInputText(Target,temp_Target,"Target"); 
 } 


 public void enter_TaxId1(String temp_TaxId1){ 
 
 enterInputText(TaxId1,temp_TaxId1,"TaxId1"); 
 } 


 public void enter_VisibilityType1(String temp_VisibilityType1){ 
 
 enterInputText(VisibilityType1,temp_VisibilityType1,"VisibilityType1"); 
 } 


 public void select_Vulnerability1(String temp_Vulnerability1){ 
 
 selectVisibileText(Vulnerability1,temp_Vulnerability1,"Vulnerability1"); 
 } 


 public void select_moreactions(String temp_moreactions){ 
 
 selectVisibileText(moreactions,temp_moreactions,"moreactions"); 
 } 


 public void select_radio_tab10_REPORTTEMPLATE(String temp_radio_tab10_REPORTTEMPLATE){ 
 
 selectRadioButton(radio_tab10_REPORTTEMPLATE, temp_radio_tab10_REPORTTEMPLATE,"radio tab10 REPORTTEMPLATE"); 
 } 


 public void select_radio_tab7_CONFIDTXT(String temp_radio_tab7_CONFIDTXT){ 
 
 selectRadioButton(radio_tab7_CONFIDTXT, temp_radio_tab7_CONFIDTXT,"radio tab7 CONFIDTXT"); 
 } 


 public void select_radio_tab7_INTERNETBANKINGSERVICE(String temp_radio_tab7_INTERNETBANKINGSERVICE){ 
 
 selectRadioButton(radio_tab7_INTERNETBANKINGSERVICE, temp_radio_tab7_INTERNETBANKINGSERVICE,"radio tab7 INTERNETBANKINGSERVICE"); 
 } 


 public void select_radio_tab7_MOBILEBANKINGSERVICE(String temp_radio_tab7_MOBILEBANKINGSERVICE){ 
 
 selectRadioButton(radio_tab7_MOBILEBANKINGSERVICE, temp_radio_tab7_MOBILEBANKINGSERVICE,"radio tab7 MOBILEBANKINGSERVICE"); 
 } 


 public void select_radio_tab8_AMLCHECK(String temp_radio_tab8_AMLCHECK){ 
 
 selectRadioButton(radio_tab8_AMLCHECK, temp_radio_tab8_AMLCHECK,"radio tab8 AMLCHECK"); 
 } 


 public void select_radio_tab8_KYCCOMPLETE(String temp_radio_tab8_KYCCOMPLETE){ 
 
 selectRadioButton(radio_tab8_KYCCOMPLETE, temp_radio_tab8_KYCCOMPLETE,"radio tab8 KYCCOMPLETE"); 
 } 


 public void select_radio_tab9_NOUPDATECRM(String temp_radio_tab9_NOUPDATECRM){ 
 
 selectRadioButton(radio_tab9_NOUPDATECRM, temp_radio_tab9_NOUPDATECRM,"radio tab9 NOUPDATECRM"); 
 } 
}
