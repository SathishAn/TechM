package TechMQA;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import utilities.CoreTapWrappers;

public class T24_CustomerCreationPage_Glue extends CoreTapWrappers {

T24_CustomerCreationPage t24_customercreationpage = new T24_CustomerCreationPage();public void seletonGlueCode(){




t24_customercreationpage.select_AMLResult(excelHashMapValues.get("AMLResult"));


t24_customercreationpage.enter_AccountOfficer(excelHashMapValues.get("AccountOfficer")); 


t24_customercreationpage.enter_AnnualBonus1(excelHashMapValues.get("AnnualBonus1")); 


t24_customercreationpage.click_Audit();


t24_customercreationpage.enter_AutoNextKYCRev(excelHashMapValues.get("AutoNextKYCRev")); 


t24_customercreationpage.enter_AutoNextSuitRev(excelHashMapValues.get("AutoNextSuitRev")); 


t24_customercreationpage.enter_BranchName(excelHashMapValues.get("BranchName")); 


t24_customercreationpage.select_BulkPaymentRequired(excelHashMapValues.get("BulkPaymentRequired"));


t24_customercreationpage.enter_CalcRiskClass(excelHashMapValues.get("CalcRiskClass")); 


t24_customercreationpage.enter_ChangeDate1(excelHashMapValues.get("ChangeDate1")); 


t24_customercreationpage.enter_ChangeReason1(excelHashMapValues.get("ChangeReason1")); 


t24_customercreationpage.select_CommType1(excelHashMapValues.get("CommType1"));


t24_customercreationpage.click_CommunicationDetails();


t24_customercreationpage.enter_ContactDate(excelHashMapValues.get("ContactDate")); 


t24_customercreationpage.enter_CrCalcRestDate1(excelHashMapValues.get("CrCalcRestDate1")); 


t24_customercreationpage.enter_CrUserProfile1(excelHashMapValues.get("CrUserProfile1")); 


t24_customercreationpage.enter_CrUserProfileType1(excelHashMapValues.get("CrUserProfileType1")); 


t24_customercreationpage.enter_CustomerCurrency1(excelHashMapValues.get("CustomerCurrency1")); 


t24_customercreationpage.enter_CustomerLiability(excelHashMapValues.get("CustomerLiability")); 


t24_customercreationpage.enter_CustomerRating1(excelHashMapValues.get("CustomerRating1")); 


t24_customercreationpage.enter_CustomerSalary1(excelHashMapValues.get("CustomerSalary1")); 


t24_customercreationpage.enter_CustomerSince(excelHashMapValues.get("CustomerSince")); 


t24_customercreationpage.enter_CustomerStatus(excelHashMapValues.get("CustomerStatus")); 


t24_customercreationpage.select_CustomerType(excelHashMapValues.get("CustomerType"));


t24_customercreationpage.enter_DateofBirth(excelHashMapValues.get("DateofBirth")); 


t24_customercreationpage.select_DocumentName1(excelHashMapValues.get("DocumentName1"));


t24_customercreationpage.enter_EmailAddress1(excelHashMapValues.get("EmailAddress1")); 


t24_customercreationpage.enter_EmployersAddress11(excelHashMapValues.get("EmployersAddress11")); 


t24_customercreationpage.enter_EmployersBusiness1(excelHashMapValues.get("EmployersBusiness1")); 


t24_customercreationpage.enter_EmployersName1(excelHashMapValues.get("EmployersName1")); 


t24_customercreationpage.enter_EmploymentStartDt1(excelHashMapValues.get("EmploymentStartDt1")); 


t24_customercreationpage.select_EmploymentStatus1(excelHashMapValues.get("EmploymentStatus1"));


t24_customercreationpage.enter_ExpirationDate1(excelHashMapValues.get("ExpirationDate1")); 


t24_customercreationpage.enter_FAMILYNAME(excelHashMapValues.get("FAMILYNAME")); 


t24_customercreationpage.enter_Fax1(excelHashMapValues.get("Fax1")); 


t24_customercreationpage.click_FinancialDetails();


t24_customercreationpage.click_FurtherDetails();


t24_customercreationpage.enter_GBAddress1(excelHashMapValues.get("GBAddress1")); 


t24_customercreationpage.enter_GBCountry(excelHashMapValues.get("GBCountry")); 


t24_customercreationpage.enter_GBFullName(excelHashMapValues.get("GBFullName")); 


t24_customercreationpage.enter_GBFullName2(excelHashMapValues.get("GBFullName2")); 


t24_customercreationpage.enter_GBPostCode(excelHashMapValues.get("GBPostCode")); 


t24_customercreationpage.enter_GBShortName(excelHashMapValues.get("GBShortName")); 


t24_customercreationpage.enter_GBStreet(excelHashMapValues.get("GBStreet")); 


t24_customercreationpage.enter_GBTownCity(excelHashMapValues.get("GBTownCity")); 


t24_customercreationpage.enter_GIVENNAMES(excelHashMapValues.get("GIVENNAMES")); 


t24_customercreationpage.select_Gender(excelHashMapValues.get("Gender")); 


t24_customercreationpage.enter_HoldingsPivot1(excelHashMapValues.get("HoldingsPivot1")); 


t24_customercreationpage.click_IDDoc();


t24_customercreationpage.enter_Industry(excelHashMapValues.get("Industry")); 


t24_customercreationpage.enter_Interests1(excelHashMapValues.get("Interests1")); 


t24_customercreationpage.enter_Introducer(excelHashMapValues.get("Introducer")); 


t24_customercreationpage.enter_IssueAuthority1(excelHashMapValues.get("IssueAuthority1")); 


t24_customercreationpage.select_IssueCheque(excelHashMapValues.get("IssueCheque"));


t24_customercreationpage.enter_IssueDate1(excelHashMapValues.get("IssueDate1")); 


t24_customercreationpage.enter_JobTitle1(excelHashMapValues.get("JobTitle1")); 


t24_customercreationpage.click_KYC();


t24_customercreationpage.enter_KycRelationship(excelHashMapValues.get("KycRelationship")); 


t24_customercreationpage.enter_Language(excelHashMapValues.get("Language")); 


t24_customercreationpage.enter_LastAMLResultDt(excelHashMapValues.get("LastAMLResultDt")); 


t24_customercreationpage.enter_LastKYCReviewDate(excelHashMapValues.get("LastKYCReviewDate")); 


t24_customercreationpage.enter_LastSuitReviewDate(excelHashMapValues.get("LastSuitReviewDate")); 


t24_customercreationpage.enter_LegalID1(excelHashMapValues.get("LegalID1")); 


t24_customercreationpage.enter_MORTGAGEAMT(excelHashMapValues.get("MORTGAGEAMT")); 


t24_customercreationpage.enter_ManualNextKYCRev(excelHashMapValues.get("ManualNextKYCRev")); 


t24_customercreationpage.enter_ManualNextSuitRev(excelHashMapValues.get("ManualNextSuitRev")); 


t24_customercreationpage.enter_ManualRiskClass(excelHashMapValues.get("ManualRiskClass")); 


t24_customercreationpage.select_MaritalStatus(excelHashMapValues.get("MaritalStatus"));


t24_customercreationpage.enter_Mnemonic(excelHashMapValues.get("Mnemonic")); 


t24_customercreationpage.enter_MobilePhoneNumbers1(excelHashMapValues.get("MobilePhoneNumbers1")); 


t24_customercreationpage.enter_MoreRoleInfo11(excelHashMapValues.get("MoreRoleInfo11")); 


t24_customercreationpage.enter_NameonID1(excelHashMapValues.get("NameonID1")); 


t24_customercreationpage.enter_Nationality(excelHashMapValues.get("Nationality")); 


t24_customercreationpage.enter_NetMonthlyIn(excelHashMapValues.get("NetMonthlyIn")); 


t24_customercreationpage.enter_NetMonthlyOut(excelHashMapValues.get("NetMonthlyOut")); 


t24_customercreationpage.enter_NoofDependents(excelHashMapValues.get("NoofDependents")); 


t24_customercreationpage.enter_Occupation1(excelHashMapValues.get("Occupation1")); 


t24_customercreationpage.click_OtherDetails();


t24_customercreationpage.enter_OtherNationality1(excelHashMapValues.get("OtherNationality1")); 


t24_customercreationpage.enter_PhoneNumbersOff1(excelHashMapValues.get("PhoneNumbersOff1")); 


t24_customercreationpage.enter_PhoneNumbersRes1(excelHashMapValues.get("PhoneNumbersRes1")); 


t24_customercreationpage.enter_PrefChannel1(excelHashMapValues.get("PrefChannel1")); 


t24_customercreationpage.enter_PreviousName1(excelHashMapValues.get("PreviousName1")); 


t24_customercreationpage.enter_PreviousVisibilityType1(excelHashMapValues.get("PreviousVisibilityType1")); 


t24_customercreationpage.enter_ProbabilityofDefault1(excelHashMapValues.get("ProbabilityofDefault1")); 


t24_customercreationpage.enter_RESIDENCESINCE(excelHashMapValues.get("RESIDENCESINCE")); 


t24_customercreationpage.select_RESIDENCESTATUS(excelHashMapValues.get("RESIDENCESTATUS"));


t24_customercreationpage.select_RESIDENCETYPE(excelHashMapValues.get("RESIDENCETYPE"));


t24_customercreationpage.enter_RESIDENCEVALUE(excelHashMapValues.get("RESIDENCEVALUE")); 


t24_customercreationpage.click_Relation();


t24_customercreationpage.enter_RelationCode1(excelHashMapValues.get("RelationCode1")); 


t24_customercreationpage.enter_RelationCustomer1(excelHashMapValues.get("RelationCustomer1")); 


t24_customercreationpage.select_RelationDelvOption11(excelHashMapValues.get("RelationDelvOption11"));


t24_customercreationpage.click_ReportingDetails();


t24_customercreationpage.enter_Residence(excelHashMapValues.get("Residence")); 


t24_customercreationpage.click_ResidentialDetails();


t24_customercreationpage.enter_RiskAssetType1(excelHashMapValues.get("RiskAssetType1")); 


t24_customercreationpage.enter_RiskFromDate1(excelHashMapValues.get("RiskFromDate1")); 


t24_customercreationpage.enter_RiskLevel1(excelHashMapValues.get("RiskLevel1")); 


t24_customercreationpage.enter_RiskTolerance1(excelHashMapValues.get("RiskTolerance1")); 


t24_customercreationpage.enter_Role11(excelHashMapValues.get("Role11")); 


t24_customercreationpage.enter_RoleNotes11(excelHashMapValues.get("RoleNotes11")); 


t24_customercreationpage.enter_SalaryDateFreq1(excelHashMapValues.get("SalaryDateFreq1")); 


t24_customercreationpage.enter_SecondOfficer1(excelHashMapValues.get("SecondOfficer1")); 


t24_customercreationpage.enter_Sector(excelHashMapValues.get("Sector")); 


t24_customercreationpage.enter_SpokenLanguage1(excelHashMapValues.get("SpokenLanguage1")); 


t24_customercreationpage.select_TITLE(excelHashMapValues.get("TITLE"));


t24_customercreationpage.enter_Target(excelHashMapValues.get("Target")); 


t24_customercreationpage.enter_TaxId1(excelHashMapValues.get("TaxId1")); 


t24_customercreationpage.enter_VisibilityType1(excelHashMapValues.get("VisibilityType1")); 


t24_customercreationpage.select_Vulnerability1(excelHashMapValues.get("Vulnerability1"));


t24_customercreationpage.select_moreactions(excelHashMapValues.get("moreactions"));


t24_customercreationpage.select_radio_tab10_REPORTTEMPLATE(excelHashMapValues.get("radiotab10REPORTTEMPLATE")); 


t24_customercreationpage.select_radio_tab7_CONFIDTXT(excelHashMapValues.get("radiotab7CONFIDTXT")); 


t24_customercreationpage.select_radio_tab7_INTERNETBANKINGSERVICE(excelHashMapValues.get("radiotab7INTERNETBANKINGSERVICE")); 


t24_customercreationpage.select_radio_tab7_MOBILEBANKINGSERVICE(excelHashMapValues.get("radiotab7MOBILEBANKINGSERVICE")); 


t24_customercreationpage.select_radio_tab8_AMLCHECK(excelHashMapValues.get("radiotab8AMLCHECK")); 


t24_customercreationpage.select_radio_tab8_KYCCOMPLETE(excelHashMapValues.get("radiotab8KYCCOMPLETE")); 


t24_customercreationpage.select_radio_tab9_NOUPDATECRM(excelHashMapValues.get("radiotab9NOUPDATECRM")); 
}
}