package utilities;

public class BaseTestSetup {

}
