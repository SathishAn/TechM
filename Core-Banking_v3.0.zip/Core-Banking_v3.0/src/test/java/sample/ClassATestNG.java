package sample;

import org.testng.annotations.Test;

public class ClassATestNG {

	
	@Test
	public void test() {
		System.out.println("Running test method");
	}
}
