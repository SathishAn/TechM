package dgen;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Random;
import java.util.Map.Entry;
import javax.net.ssl.*;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.xml.DOMConfigurator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import javafx.collections.ObservableList;

public class ExecutionProcess implements Runnable {
	static Fillo fillo = new Fillo();
	private static String User_Agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36";
	public static HashMap<String, String> testData, validate;
	
	public static HashMap<String, String> result;
	public static HashMap<String, String> cookies;
	public static HashMap<String, String> environData;
	public static HashMap<String, Integer> iteration;
	private final String propertyFilePath = "./configs/config.properties";
	private static String iRegion;
	private static String appUrl;
	private static ObservableList<Modules> moduleList;
	private static String reportPath,reportfile, fileName , logFile;
	private static boolean status;
	private static boolean columnFlag;
	private static Logger logs = Logger.getLogger(ExecutionProcess.class);
	
	public ExecutionProcess(ObservableList<Modules> moduleList) {
		try {
			this.moduleList = moduleList;
			
			environData = new HashMap<>();
			BufferedReader reader = new BufferedReader(new FileReader(propertyFilePath));
			Properties properties = new Properties();
			properties.load(reader);
			for (Entry<Object, Object> prop : properties.entrySet()) {
				if(prop.getValue().toString().startsWith("Encrypted :~")) {
					String encryptedString = EncryptionFile.decrypt(prop.getValue().toString().replace("Encrypted :~", "").toString());
					environData.put(prop.getKey().toString(), encryptedString);
					System.out.println(encryptedString);
					
				}else {
					environData.put(prop.getKey().toString(), prop.getValue().toString());
				}
				
				appUrl = appUrl;
			}

		} catch (FileNotFoundException e) {

			logs.error(e.getMessage());
		} catch (IOException e) {

			logs.error(e.getMessage());
		}
	}


	/*****************************************************************************
	 * 
	 * Launch the Application
	 * 
	 *****************************************************************************/
	public static void loadUrl() {
		try {
			enableSSLSocket();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			logs.error(e.getMessage());
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			logs.error(e.getMessage());
		}
		cookies = new HashMap<>();
		getService(appUrl);
	}

	/*****************************************************************************
	 * 
	 * Login with Maker user to the Application
	 * 
	 *****************************************************************************/
	public static void makerLogin() {
		String userName = null, password = null;
		userName = environData.get("makerUserName");
		password = environData.get("makerPassword");
		testData = new HashMap<>();
		validate = new HashMap<>();
		iRegion = "Mizrahi";
		testData.put("command", "globusCommand");
		testData.put("requestType", "CREATE.SESSION");
		testData.put("signOnName", userName);
		testData.put("password", password);
		Document response = loginPostService(appUrl, testData);
//		getDate();
	}
	
	public static void getDate() {
		testData.put("command", "globusCommand");
		testData.put("routineArgs", "BANNER");
		testData.put("routineName", "OS.NEW.USER");
		Document response = postService(appUrl, testData);
		System.out.println(response.html());
		Elements date = response.select("input[id=\"today\"]");
		String today = date.attr("value");
		System.out.println(today);
	}

	/*****************************************************************************
	 * 
	 * Login with authorize user to the Application
	 * 
	 *****************************************************************************/
	public static void authorizerLogin() {
		String userName = null, password = null;
		userName = environData.get("authoriseUser");
		password = environData.get("authorisePassword");		
		testData = new HashMap<>();
		validate = new HashMap<>();
		testData.put("command", "globusCommand");
		testData.put("requestType", "CREATE.SESSION");
		testData.put("signOnName", userName);
		testData.put("password", password);
		loginPostService(appUrl, testData);
	}


	/*****************************************************************************
	 * 
	 * Validate the Target
	 * 
	 *****************************************************************************/
	public static void validateTarget(int iCount, String wbName) {
		String transactionId, comments = null;
		String module = "ContainerCustomer", iStatus;
		logs.info("Reference Number : " + module + " " +  iCount);
		String[] colName = {"CustomerNumber" ,"Status", "Comments" };
		createHeaders(module, colName);
		loadUrl();
		makerLogin();
		extractFormData("ValidateTarget");
		extractExcelData("Target", wbName);
		Document response = postService(appUrl, testData);
		Elements TransactionID = response.select("input[id=\"transactionId\"]");
		transactionId = TransactionID.attr("value");
		if(!TransactionID.equals(testData.get("transactionId"))) {
			status = false;
			comments= TransactionID + "failed";
		}
			
		result.put("ScenarioName", module + iCount);
		result.put("CustomerNumber", transactionId);
		result.put("Comments", comments);
		if (status) {
			result.put("Status", "PASS");
		} else {
			result.put("Status", "FAIL");
		}
		updateTestData(module, result);	
		
	}
	

	 //*************************************************************************************/
	public static void getService(String iURl) {

		try {
			Connection.Response appUrl = Jsoup.connect(iURl).method(Connection.Method.GET).userAgent(User_Agent).timeout(20000)
					.execute();

			cookies.putAll(appUrl.cookies());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logs.error(e.getMessage());
		}

	}

	public static Document loginPostService(String iUrl, HashMap<String, String> formData) {
		Document responseText = null;
		try {
			Connection.Response loginForm = Jsoup.connect(iUrl).cookies(cookies).data(formData)
					.method(Connection.Method.POST).userAgent(User_Agent).timeout(70000).execute();
			cookies.clear();

			cookies.putAll(loginForm.cookies());
			responseText = loginForm.parse();
		} catch (IOException e) {
				logs.error(e.getMessage());
		}
		return responseText;
	}

	public static Document postService(String iUrl, HashMap<String, String> formData) {
		Document responseText = null;
		try {
			Connection.Response serviceUrl = Jsoup.connect(iUrl).cookies(cookies).data(formData)
					.method(Connection.Method.POST).userAgent(User_Agent).timeout(70000).execute();

			responseText = serviceUrl.parse();

		} catch (IOException e) {
			logs.error(e.getMessage());
		}
		return responseText;

	}

	public static HashMap<String, String> extractFormData(String ScenarioName) {
		com.codoid.products.fillo.Connection connection = null;
		String sheetName = null;
			sheetName = "Mizrahi";
		
		Recordset recordset = null;
		try {
			connection = fillo.getConnection("./resources/DGenInput.xlsx");
			String strQuery = "Select * from " + sheetName + " where ScenarioName='" + ScenarioName + "'";
			recordset = connection.executeQuery(strQuery);
			while (recordset.next()) {
				ArrayList<String> ColCollection = recordset.getFieldNames();
				int iCount;
				int size = ColCollection.size();
				for (int Iter = 0; Iter <= (size - 1); Iter++) {

					String ColName = ColCollection.get(Iter);
					String ColValue = recordset.getField(ColName);
					if (!ColName.equalsIgnoreCase("ScenarioName")) {
						if (!ColValue.isEmpty()) {
							testData.put(ColName, ColValue);
						}

					}

				}
			}

		} catch (FilloException e) {
			// TODO Auto-generated catch block 
			logs.error(e.getMessage());
		} finally {
			recordset.close();
			connection.close();
		}

		return testData;
	}

	public static HashMap<String, String> extractExcelData(String sheetname, String wbName) {
		com.codoid.products.fillo.Connection connection = null;
		Recordset recordset = null;
		int iRecordCount, i = 1;
		try {
			connection = fillo.getConnection("./resources/InputData/" + iRegion + "/"+ wbName +".xlsx");
			String strQuery = "Select * from " + sheetname + " where ExecutionFlag='Y'";
			recordset = connection.executeQuery(strQuery);
			iRecordCount = recordset.getCount();
			if(!iteration.containsKey(sheetname)) {
				iteration.put(sheetname, 1);
			}
			
			
			if(iteration.get(sheetname) <= iRecordCount) {
				//iteration++;
			}else {
				iteration.put(sheetname, 1);
			}
			while (recordset.next()) {
				int svalue = iteration.get(sheetname);
				if(i == iteration.get(sheetname)) {
					ArrayList<String> ColCollection = recordset.getFieldNames();
					int iter;
					int size = ColCollection.size();
					for (iter = 0; iter <= (size - 1); iter++) {
	
						String ColName = ColCollection.get(iter);
						String ColValue = recordset.getField(ColName);
						if (!ColName.equalsIgnoreCase("ScenarioName")) {
							if (!ColValue.isEmpty()) {
								testData.put(ColName, ColValue);
							}
	
						}
						
					}
					svalue++;
					iteration.put(sheetname, svalue);					
					break;
					}else {
						i++;
					}
					
			}

		} catch (FilloException e) {
			// TODO Auto-generated catch block
			logs.error(e.getMessage());
		} finally {
			recordset.close();
			connection.close();
		}
 
		return testData;
	}

	public static void updateTestData(String Sheetname, HashMap<String, String> result) {
		com.codoid.products.fillo.Connection connection = null;
		try {
			connection = fillo.getConnection(reportfile);
			StringBuffer setKey = new StringBuffer();
			StringBuffer setValue = new StringBuffer();
			for (Entry<String, String> rst : result.entrySet()) {
				if (setKey.toString().isEmpty()) {
					setKey.append("(" + rst.getKey());
				} else {
					setKey.append("," + rst.getKey());
				}

				if (setValue.toString().isEmpty()) {
					setValue.append("('" + rst.getValue() + "'");
				} else {
					setValue.append(", '" + rst.getValue() + "'");
				}
			}

			String strQuery = "Insert INTO " + Sheetname + setKey.toString() + ") VALUES " + setValue.toString() + ")";
			connection.executeUpdate(strQuery);
			connection.close();
		} catch (FilloException e) {
			
			logs.error(e.getMessage());
		}

	}
	
	public void callMethodByModule(String moduleName, Integer iCount, String region) {
		
		columnFlag = true;
		iRegion = region;
		iteration = new HashMap<>();
		for (int i = 1; i <= iCount; i++) {
	        logs.info("***********************************************************");
			result = new HashMap<>();
			status = true;
			switch (moduleName.toLowerCase()) {
			case "01.Target":
				validateTarget(i, moduleName);
				break;			
				
			default:
				break;
			}
		}

	}
	
	private static void createHeaders(String name, String[] arg) {
		if (columnFlag) {
			XSSFWorkbook workbook;
			XSSFSheet sheet;
			FileOutputStream out;
			Row row;
			Cell cell;
			File fl = new File(reportfile);
			try {
				FileInputStream input = new FileInputStream(fl);
				workbook = new XSSFWorkbook(input);
				sheet = workbook.createSheet(name);
				row = sheet.createRow(0);
				cell = row.createCell(0);
				sheet.setColumnWidth(0, 5000);
				System.out.println("Scenarioname  created");
				cell.setCellValue("ScenarioName");
				for (int i = 0; i < arg.length; i++) {
					cell = row.createCell(i + 1);
					cell.setCellValue(arg[i]);
					sheet.setColumnWidth(i+1, 5000);
					System.out.println(arg[i] + "created");
					
				}
				
				out = new FileOutputStream(fl);
				workbook.write(out);
				out.close();
				columnFlag = false;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logs.error(e.getMessage());
			}
		}

	}

	public static void enableSSLSocket() throws NoSuchAlgorithmException, KeyManagementException {
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {

			@Override
			public boolean verify(String hostname, SSLSession session) {
				// TODO Auto-generated method stub
				return true;
			}
		});

		SSLContext context = SSLContext.getInstance("TLS");
		context.init(null, new X509TrustManager[] { new X509TrustManager() {
			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}

			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}
		} }, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(context.getSocketFactory());
	}

	@Override
	public void run() {
		
		RollingFileAppender appender = new RollingFileAppender();
		
		this.createOutputFolder();
		
			logs.removeAppender(appender);
			this.logFile =reportPath + "/"+ "logFile_CH.log";
			appender.setAppend(true);
			appender.setFile(this.logFile);
			appender.activateOptions();
			PatternLayout layOut = new PatternLayout();
	        layOut.setConversionPattern("%d{yyyy-MM-dd HH:mm:ss} %-5p [%c{1}] - %m%n");
	        appender.setLayout(layOut);
	        logs.addAppender(appender);
			this.createOutputFile("MizrahiOutput");
			for (Modules lst : moduleList) {
				if (lst.getIMizrahiSelect().isSelected()) {
					// this.createsheet(lst.getModuleName());
					int endNumber = Integer.parseInt(lst.getICount());
					callMethodByModule(lst.getModuleName(), endNumber, "CH");
				}
			}
		
			
		JOptionPane.showMessageDialog(null, "Completed", "Information", 1);
	}
	
	
	private void createOutputFolder() {
		SimpleDateFormat formatdate = new SimpleDateFormat("dd-MM-YYYY");
		java.util.Date date = new java.util.Date(); 
		String newDate = formatdate.format(date).toString();
		System.out.println(newDate);
		reportPath = "./reports/"+newDate;
		 File directory = new File(reportPath);
	  		if (!directory.exists()) {
	  			directory.mkdirs();
	  			System.out.println("Output folder created");
	  		}
	  		formatdate = new SimpleDateFormat("HH-mm-ss");
			newDate = formatdate.format(date).toString();
			reportPath = reportPath + "/" + newDate;
			directory = new File(reportPath);
			if (!directory.exists()) {
	  			directory.mkdirs();
	  			logs.info("Output folder created");
	  		}
	}
	
	
	
	
	private void createOutputFile(String fileName) {
		this.fileName = fileName;	
		this.reportfile = reportPath + "/" + this.fileName +".xlsx";
	  	File fl = new File(reportfile);
	  	if (!fl.exists()){	
	  		try {
	  			FileOutputStream out = new FileOutputStream(fl);
	  			XSSFWorkbook workbook = new XSSFWorkbook();
				workbook.write(out);
				logs.info("Output File created");
				out.close();
			} catch (IOException e) {
				logs.error(e.getMessage());
			}
	  	}
	}
	
	
	
	public void loadReportPath()  {
		try {
			File relPath = new File(reportPath);
			File parentFolder = new File(relPath.getParent());
			File absPath = new File(parentFolder, "../."+ reportPath );
			String absolute = absPath.getCanonicalPath() ;
			System.out.println(absolute);
			Runtime.getRuntime().exec("cmd /c start "+ absolute);
		} catch (IOException e) {
			
			logs.error("No Output files Generated");
		}
	}

}
