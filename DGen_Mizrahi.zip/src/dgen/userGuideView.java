package dgen;

public class userGuideView {

	public void createUserGuide() {
		String helpviewHtml = null;
		StringBuilder htmlbulider = new StringBuilder();
		htmlbulider.append("<html><head> <body>");
		htmlbulider.append("<html><body>");
		
		htmlbulider.append("</body></html>");
		
	}
}
