package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;

import utilities.CoreTapWrappers;

public class DemoPage extends CoreTapWrappers {
	
	
	public DemoPage(WebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;		 
		PageFactory.initElements(this.driver, this);
		if(!verifyTitle("Sat")){
			reportStep("This is not Page", "FAIL");
		}
	}
	
	@FindBy(how=How.NAME, using="firstname")
	public WebElement txtbx_FirstName;
	
	@FindBy(how=How.NAME,using="lastname")
	public WebElement txtbx_LastName;
	
	
	public void enterFirstName(String firstName) {		
		enterInputText(txtbx_FirstName, firstName, "First Name");		
	}
	
	public void getFirstName() {
		getTextWebElement(txtbx_FirstName, "First Name");
		
		
	}
	
	public void enterLastName(String lastName) {
		enterInputText(txtbx_LastName, lastName, "Last Name");
		
	}
	

}
