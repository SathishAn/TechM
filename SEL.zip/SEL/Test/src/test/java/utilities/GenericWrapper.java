package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class GenericWrapper extends Reporter implements Wrapper {
	public static WebDriver driver;
	public static WebDriverWait wait;

	public GenericWrapper() {
	}

	public GenericWrapper(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.test = test;
	}
	
	/* ---------------------------------------------------------------------
    Method Name: invokeApp
    Description: This method will launch the given browser and maximize the browser and set the wait for 30 seconds and load the url.
    Author: Sathish A - Core Banking
	------------------------------------------------------------------------*/	
	@Override
	public void invokeApp(String browser, String Url) {
		// TODO Auto-generated method stub
		System.out.println("invokeapp");
		try {
			if (browser.equalsIgnoreCase("Chrome")) {
				System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
				driver = new ChromeDriver();
			} else {
				System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
				driver = new FirefoxDriver();
			}
			driver.get(Url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			reportStep("The browser " + browser + " launched successfully.", "PASS");
			System.out.println("The browser " + browser + " launched successfully.");
		} catch (WebDriverException e) {
			reportStep("The browser " + browser + " launched successfully.", "PASS", false);
			System.out.println("The Browser is unexpectedly closed");
		} finally {
			takeSnap();
		}

	}
	/* ---------------------------------------------------------------------
    Method Name: enterInputText
    Description: This method will enter the value to the text field using locators
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void enterInputText(WebElement element, String data, String fieldName) {
		// TODO Auto-generated method stub
		try {
			element.clear();
			element.sendKeys(data);
			reportStep("The field '" + fieldName + "' is entered with text '" + data + "' successfully.", "PASS");
			System.out.println("The Text field '" + fieldName + "' is entered with text " + data + " successfully.");
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			reportStep("The element '" + fieldName + "' is not present in the application", "FAIL");
			System.out.println("The element '" + fieldName + " is not present in the application");
		} catch (WebDriverException e) {
			reportStep("The Browser is unexpectedly closed", "FAIL", false);
			System.out.println("The Browser is unexpectedly closed");
		} finally {
			takeSnap();
		}

	}
	/* ---------------------------------------------------------------------
    Method Name: verifyTitle
    Description: This method will verify the title of the browser
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public boolean verifyTitle(String title) {
		// TODO Auto-generated method stub
		boolean bReturn = false;
		try {
			if (driver.getTitle().equalsIgnoreCase(title)) {
				reportStep("The title of the page matches with the value : " + title, "PASS");
				bReturn = true;
			} else
				reportStep("The title of the page:" + driver.getTitle() + " did not match with the value :" + title,
						"SUCCESS");

		} catch (Exception e) {
			reportStep("Unknown exception occured while verifying the title", "FAIL");
		}
		return bReturn;
	}
	/* ---------------------------------------------------------------------
    Method Name: verifyText
    Description: This method will verify the given text with exact match.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void verifyText(WebElement element, String text) {
		// TODO Auto-generated method stub

	}
	/* ---------------------------------------------------------------------
    Method Name: verifyTextContains
    Description: This method will verify the given text with partial match.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void verifyTextContains(WebElement element, String text) {
		// TODO Auto-generated method stub

	}
	/* ---------------------------------------------------------------------
    Method Name: webElementClick
    Description: This method will click the element using a locator
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void webElementClick(WebElement element, String fieldName) {
		// TODO Auto-generated method stub
		try {
			element.click();
			reportStep("The element '" + fieldName + "' is clicked.", "PASS");
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			reportStep("The element '" + fieldName + "' is not present in the application", "FAIL");
		} finally {
			takeSnap();
		}

	}
	/* ---------------------------------------------------------------------
    Method Name: getTextWebElement
    Description: This method will get the text of the element using locator
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public String getTextWebElement(WebElement element, String fieldName) {
		// TODO Auto-generated method stub
		StringBuffer tempValue = new StringBuffer();
		try {
			tempValue.append(element.getText());
			reportStep( "'" + tempValue.toString() + "' is reterived form the element '" + fieldName + "'", "PASS");
		} catch (NoSuchElementException e) {
			reportStep("The element '" + fieldName + "' is not present in the application", "FAIL");
		} finally {
			takeSnap();
		}

		return tempValue.toString();
	}
	/* ---------------------------------------------------------------------
    Method Name: selectVisibileText
    Description: This method will select the drop down visible text using locator
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void selectVisibileText(WebElement element, String value, String fieldName) {
		// TODO Auto-generated method stub
		try {
			new Select(element).selectByVisibleText(value);
			reportStep("The element '"+ fieldName +"' is selected with value :" + value, "PASS");
		} catch (Exception e) {
			reportStep("The value: " + value + " could not be selected.", "FAIL");
		}

	}
	/* ---------------------------------------------------------------------
    Method Name: selectByValue
    Description: This method will select the drop down visible value using locator
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void selectByValue(WebElement element, String value) {
		// TODO Auto-generated method stub

	}
	/* ---------------------------------------------------------------------
    Method Name: selectByIndex
    Description: This method will select the drop down using index as locator
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void selectByIndex(WebElement element, int value) {
		// TODO Auto-generated method stub

	}
	/* ---------------------------------------------------------------------
    Method Name: switchToLastWindow
    Description: This method will move the control to the last window.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void switchToLastWindow() {
		// TODO Auto-generated method stub
		try {
			Set<String> winHandles = driver.getWindowHandles();
			for (String wHandle : winHandles) {
				driver.switchTo().window(wHandle);
			}
		} catch (Exception e) {
			reportStep("The window could not be switched to the last window.", "FAIL");
		}
	}
	/* ---------------------------------------------------------------------
    Method Name: switchToParentWindow
    Description: This method will switch to the parent Window
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void switchToParentWindow() {
		// TODO Auto-generated method stub
		try {
			Set<String> winHandles = driver.getWindowHandles();
			for (String wHandle : winHandles) {
				driver.switchTo().window(wHandle);
				break;
			}
		} catch (Exception e) {
			reportStep("The window could not be switched to the first window.", "FAIL");
		}
	}
	/* ---------------------------------------------------------------------
    Method Name: acceptAlert
    Description: This method will accept the alert opened
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void acceptAlert() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Alert");
			driver.switchTo().alert().accept();
		} catch (NoAlertPresentException e) {
			reportStep("The alert could not be found.", "FAIL");
		} catch (Exception e) {
			reportStep("The alert could not be accepted.", "FAIL");
		}
	}
	
	/* ---------------------------------------------------------------------
    Method Name: dismissAlert
    Description: This method will dismiss the alert opened
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void dismissAlert() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Alert");
			driver.switchTo().alert().dismiss();
		} catch (NoAlertPresentException e) {
			reportStep("The alert could not be found.", "FAIL");
		} catch (Exception e) {
			reportStep("The alert could not be accepted.", "FAIL");
		}
	}
	/* ---------------------------------------------------------------------
    Method Name: dismissAlert
    Description: This method will dismiss the alert opened
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public String getAlertText() {
		// TODO Auto-generated method stub
		StringBuffer tempValue = new StringBuffer();

		try {
			System.out.println("Alert");
			tempValue.append(driver.switchTo().alert().getText());
		} catch (NoAlertPresentException e) {
			reportStep("The alert could not be found.", "FAIL");
		} catch (Exception e) {
			reportStep("The alert could not be accepted.", "FAIL");
		}
		return tempValue.toString();
	}
	
	/* ---------------------------------------------------------------------
    Method Name: closeBrowser
    Description: This method will close the active browser.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void closeBrowser() {
		// TODO Auto-generated method stub
		driver.close();

	}
	/* ---------------------------------------------------------------------
    Method Name: closeAllBrowsers
    Description: This method will close all the browsers of the given execution session
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void closeAllBrowsers() {
		// TODO Auto-generated method stub
		driver.quit();

	}
	/* ---------------------------------------------------------------------
    Method Name: webElementWait
    Description: This method will wait for the element.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void webElementWait(WebElement element, String syncValue, String waitType) {
		wait = new WebDriverWait(driver, Integer.parseInt(syncValue));
		try {
			switch (waitType.toLowerCase()) {
			case "visible":
				wait.until(ExpectedConditions.visibilityOf(element));
				break;
			case "clickable":
				wait.until(ExpectedConditions.elementToBeClickable(element));
				break;

			case "selectable":
				wait.until(ExpectedConditions.elementToBeSelected(element));
				break;

			default:
				wait.until(ExpectedConditions.presenceOfElementLocated((By) element));
				break;
			}

		} catch (Exception e) {

		}

	}
	/* ---------------------------------------------------------------------
    Method Name: mouseOver
    Description: This method is used to move the mouse cursor to the webelement.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void mouseOver(WebElement element) {
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element).build().perform();
			reportStep("The mouse over  is performed.", "PASS");
		} catch (Exception e) {
			reportStep("The mouse over could not be performed.", "FAIL");
		}
	}
	/* ---------------------------------------------------------------------
    Method Name: takeSnap
    Description: This method is used to capture the screen.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public long takeSnap() {
		// TODO Auto-generated method stub
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L;
		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE),
					new File("./reports/images/" + number + ".jpg"));
		} catch (WebDriverException e) {
			reportStep("The browser has been closed.", "FAIL");
		} catch (IOException e) {
			reportStep("The snapshot could not be taken", "WARN");
		}
		return number;

	}
	
	/* ---------------------------------------------------------------------
    Method Name: actionDoubleClick
    Description: This method is used to move the mouse cursor and double click on the webelement.
    Author: Sathish A
	------------------------------------------------------------------------*/
	@Override
	public void actionDoubleClick(WebElement element, String fieldName) {
		try {
			Actions action = new Actions(driver);
			action.moveToElement(element).doubleClick().build().perform();
			reportStep("The double click is performed in the element'" + fieldName + "'", "PASS");
		} catch (Exception e) {
			reportStep("The double click could not be performed.", "FAIL");
		}
	}

}
