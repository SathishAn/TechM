package iEasy;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Screen;

public class IEasy_Controller implements Initializable {
	
	
	
	
	 @FXML
	    private BorderPane BorderPane;
	 
	 @FXML
	 	private Button btn_StepDefination;
	 @FXML
	 	private Button btn_ObjectSpy;
	 
	 @FXML
	 private TabPane tabPane;
	 
	@FXML
	private TextFlow HomeTextFlow;

	@FXML
	private void createStepDefinations() throws IOException { 
		 StepDefinationTabController step = new StepDefinationTabController();
		System.out.println("StepDefinations");
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(new URL("file:///D:/CBA_Framework/Core-Banking_v1.0/src/test/java/iEasy/StepDefination.fxml"));
		final Tab ConfigEditor = (Tab)loader.load();
		openTabPane(ConfigEditor);
	}
	
	
	private void openTabPane(Tab tab) {
		int bFlag = 0;
		ObservableList<Tab> list = tabPane.getTabs();
		for(Tab ss: list) {
			if(ss.equals(tab)) {
				tabPane.getSelectionModel().select(tab);
				bFlag = 1;
				break;
			}
			
		}
		
		if(bFlag == 0) {
			tabPane.getTabs().add(tab);
			tabPane.getSelectionModel().select(tab);
		}
		
		
		
	}
	
	

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		Text headerText = new Text("Sample");
		
		ObservableList<Node> list = HomeTextFlow.getChildren();
		
		
		HomeTextFlow.getChildren().add(headerText);
		setToolBarIcons();
	}
	
	private void setToolBarIcons() {
		Image imgAdd = new Image("file:///D:/CBA_Framework/Core-Banking_v1.0/src/test/java/iEasy/resources/Icons/createMethods.png");
		 this.btn_StepDefination.setGraphic(new ImageView(imgAdd));
		
		
	}
	
}
