package uiTool;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.*;
import javax.swing.*;
import javax.swing.table.*;

public class FilterTableTest extends JFrame {
   
   public static void main(String args[]) {
	   JFrame frame = new JFrame();
	    frame.setUndecorated(true);
	    frame.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
	    frame.setVisible(true);
   }
}