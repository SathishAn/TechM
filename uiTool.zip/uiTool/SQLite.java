package uiTool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class SQLite {
	
	 public static void createNewTable() {
		 
		 	
	        
		 String sql = "CREATE TABLE IF NOT EXISTS ObjectDetails(\n"
					+ "ID integer PRIMARY KEY,\n"
	                + "ObjectName text NOT NULL,\n"	               
					+ "Action text NOT NULL,\n"
	                + "MethodName text NOT NULL,\n"
	                + "ExcelField text,\n"
	                + "PageName text NOT NULL\n"  
	                + ");";
	        
	        try {
	        	Connection conn = connect();	       
	            Statement stmt = conn.createStatement();	           
	            stmt.execute(sql);
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	 
	 
	 
	 
	 public static Connection connect() {  
	        // SQLite connection string  
		 	String url = "jdbc:sqlite:D://sqlite/db/iEasyDB.db";  
	        Connection conn = null;  
	        try {  
	            conn = DriverManager.getConnection(url);  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	        return conn;  
	    }  
	 
	 
	 
	 
	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String[] args) {
	        
	    	createNewTable();
	    	
	    }
	    
	    public static void insert() {  
	        String sql = "INSERT INTO ObjectDetails(ObjectName, ObjectType, Action, MethodName, ExcelColumn, PageName, Locators, LocatorValue) VALUES(?, ?, ?, ?,?,?,?,?)";  
	   
	        try{  
	            Connection conn = connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);  
	            pstmt.setString(1, "webElementWait");  
	            pstmt.setString(2, "element");
	            pstmt.setString(3, "SyncTime");
	            pstmt.setString(4, "waitType");
	            pstmt.executeUpdate();  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	        
	        
	        
	    }  
	    
	    public static void delete() {  
	        String sql = "DELETE FROM ObjectDetails WHERE ObjectName ='call Object Extractor'";  
	   
	        try{  
	            Connection conn = connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);
	            pstmt.executeUpdate();  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	    }  
	    
	    
	    public static void selectAll(String userName){  
	        String sql = "SELECT * FROM authentication Where username = '" + userName + "'";  
	          
	        try {  
	            Connection conn = connect();  
	            Statement stmt  = conn.createStatement();  
	            ResultSet rs    = stmt.executeQuery(sql);  
	              
	            // loop through the result set  
	            while (rs.next()) {  
	                System.out.println(rs.getInt("id") +  "\t" +   
	                                   rs.getString("username") + "\t");  
	            }  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	    }  
	    
	    

}
