package uiTool;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.sqlite.SQLiteConfig;
import org.sqlite.javax.SQLiteConnectionPoolDataSource;



public class SQLite {
	static String path = "D:\\Sathish\\iEasyTableStructure.xlsx";
	
	public static void iCreateTables(String tables) {
		StringBuffer sql = new StringBuffer();
		switch (tables.toLowerCase()) {
		case "wrapper":
			sql.append("CREATE TABLE IF NOT EXISTS Wrappers(\n"
					+ "Wrapper_ID Integer PRIMARY KEY,\n"
	                + "Generic_Methods text NOT NULL,\n"
	                + "Retrun_Type text NOT NULL,\n"
					+ "Parameter_1 text,\n"
	                + "Parameter_2 text,\n"
	                + "Parameter_3 text,\n"
	                + "Parameter_4 text,\n"
	                + "Parameter_5 text\n"
	                + ");");
			break;
			
		case "generic":
			sql.append("CREATE TABLE IF NOT EXISTS GenericActions(\n"
					+ "i_Actions TEXT NOT NULL PRIMARY KEY,\n"
	                + "Object_Required text NOT NULL,\n"
	                + "Argument text,\n"
	                + "Type text,\n"
					+ "i_Prefix text NOT NULL\n,"
					+ "Wrapper_ID INTEGER NOT NULL,\n"
					+ "FOREIGN KEY (Wrapper_ID) REFERENCES Wrappers (Wrapper_ID)"
	                + ");");
			break;
			
		case "objects":
			sql.append("CREATE TABLE IF NOT EXISTS Objects(\n"
					+ "Primary_Objects Text PRIMARY KEY,\n"
	                + "Object_Name Text NOT NULL,\n"
	                + "Object_Type Text NOT NULL,\n"
	                + "Locators Text NOT NULL,\n"
					+ "Properties Text NOT NULL, \n"
					+ "Page_ID INTEGER NOT NULL,\n"
					+ "FOREIGN KEY (Page_ID) REFERENCES Pages (Page_ID)"
	                + ");");
			
			break;
			
			
		case "objectdetails":
			
			sql.append("CREATE TABLE IF NOT EXISTS ObjectDetails(\n"
					+ "Object_ID INTEGER PRIMARY KEY,\n"
	                + "Object_Name Text NOT NULL,\n"
	                + "i_Actions Text NOT NULL,\n"
	                + "Method_Name Text NOT NULL,\n"
					+ "Excel_Field Text NOT NULL, \n"
					+ "Page_ID INTEGER NOT NULL,\n"					
					+ "FOREIGN KEY (i_Actions) REFERENCES GenericActions (i_Actions),"
					+ "FOREIGN KEY (Page_ID) REFERENCES Pages (Page_ID)"					
	                + ");");

			
		case "pages":
			sql.append("CREATE TABLE IF NOT EXISTS Pages(\n"
					+ "Page_ID Integer PRIMARY KEY,\n"
	                + "Page_Name Text NOT NULL\n"
	                + ");");
			break;
			
		default:
			break;
		}
		
		 try {
			 	System.out.println(sql.toString());
	        	Connection conn = connect();	       
	            Statement stmt = conn.createStatement();	 
	           
	            stmt.execute(sql.toString());
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
		
		
	}
	
	 public static void iDropTable(String tables) {
		 
		 StringBuffer sql = new StringBuffer();
			switch (tables.toLowerCase()) {
			case "wrapper":
				sql.append("DROP table 'Wrappers'");
				break;
				
			case "generic":
				sql.append("DROP table 'GenericActions'");
				break;
				
			case "objects":
			
				sql.append("DROP table 'Objects'");
				break;
			case "objectdetails":
				
				sql.append("DROP table 'ObjectDetails'");
				break;
				
			case "pages":
				sql.append("DROP table 'Pages'");
				break;
			default:
				break;
			} 	
	        
		 	 
				 //"ALTER TABLE GenericActions ADD COLUMN iPrefix VARCHAR(75)";
				 
				 
	        
	        try {
	        	Connection conn = connect();	       
	            Statement stmt = conn.createStatement();	           
	            stmt.execute(sql.toString());
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	 
	 
	 
 public static void iUpdateTable() {
		 
		 StringBuffer sql = new StringBuffer();
		
				sql.append("UPDATE 'Wrappers' SET Parameter1 = 'ObjectName' Where ID = 102");
					 
				 
	        
	        try {
	        	Connection conn = connect();	       
	            Statement stmt = conn.createStatement();	           
	            stmt.execute(sql.toString());
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	 
	 
	 
	 public static Connection connect() {  
	        // SQLite connection string  
		 	String url = "jdbc:sqlite:D:/sqlite/db/iEasyDB.db";  
	        Connection conn = null;  
	        try {  
	        	SQLiteConfig config = new SQLiteConfig();
	            config.enforceForeignKeys(true);
	            
	            conn = DriverManager.getConnection(url, config.toProperties()); 
	            
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	        return conn;  
	    }  
	 
	 
	 
	 
	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String[] args) {
	    	String iTable = "ObjectDetails";
	        
	    	iDropTable(iTable);
	    	iCreateTables(iTable);
	    	iInsertToTable(iTable);
	    	//iUpdateTable();
	    	//insert();
	    	//InsertWrappers();
	    }
	    


	    
	    
	    public static void iInsertToTable(String table) {
	    	
	    
	    	File file = new File(path);
			FileInputStream inputStream;
			 Connection conn = connect();  
	         PreparedStatement pstmt;
	         StringBuffer sql;
			try {
				inputStream = new FileInputStream(file);
				XSSFWorkbook workbook=new XSSFWorkbook(inputStream);
				XSSFSheet sheet;
				Row row ;
				int rowCount;
			switch (table.toLowerCase()) {
			case "wrapper":
				sheet = workbook.getSheetAt(0);
				rowCount = sheet.getLastRowNum();
				for (int i=1 ; i <= rowCount ; i++){
					row = sheet.getRow(i);
					sql = new StringBuffer();
					sql.append("INSERT INTO Wrappers(Wrapper_ID, Generic_Methods , Retrun_Type, Parameter_1,Parameter_2, Parameter_3, Parameter_4, Parameter_5) VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
					pstmt = conn.prepareStatement(sql.toString());
					
		            pstmt.setInt(1, Integer.parseInt(row.getCell(1).getStringCellValue()));
		            pstmt.setString(2, row.getCell(0).getStringCellValue());
		            pstmt.setString(3, row.getCell(2).getStringCellValue());
		            if(row.getCell(3) != null) {
		            	pstmt.setString(4, row.getCell(3).getStringCellValue());
		            }else {
		            	pstmt.setString(4, null);
		            }
		            if(row.getCell(4) != null) {
		            	pstmt.setString(5, row.getCell(4).getStringCellValue());
		            }else {
		            	pstmt.setString(5, null);
		            }
		            if(row.getCell(5) != null) {
		            	pstmt.setString(6, row.getCell(5).getStringCellValue());
		            }else {
		            	pstmt.setString(6, null);
		            }
		            
		            if(row.getCell(6) != null) {
		            	pstmt.setString(7, row.getCell(6).getStringCellValue());
		            }else {
		            	pstmt.setString(7, null);
		            }
		            if(row.getCell(7) != null) {
		            	pstmt.setString(8, row.getCell(7).getStringCellValue());
		            }else {
		            	pstmt.setString(8, null);
		            }
		            pstmt.executeUpdate();  
					System.out.println("Insert Row " + i);
				}
				break;
			case "generic":
				sheet = workbook.getSheetAt(1);
				rowCount = sheet.getLastRowNum();
				for (int i=1 ; i <= rowCount ; i++){
					row = sheet.getRow(i);
					sql = new StringBuffer();
					sql.append("INSERT INTO GenericActions(i_Actions, Wrapper_ID, Object_Required, Argument, i_Prefix, Type) VALUES(?, ?, ?, ?, ?, ?)");
					pstmt = conn.prepareStatement(sql.toString());
					 pstmt.setString(1, row.getCell(0).getStringCellValue());
			         pstmt.setString(2, row.getCell(1).getStringCellValue());
			         pstmt.setString(3, row.getCell(2).getStringCellValue());
					 if(row.getCell(3) != null) {
			            	pstmt.setString(4, row.getCell(3).getStringCellValue());
			            }else {
			            	pstmt.setString(4, null);
			            }
			            if(row.getCell(4) != null) {
			            	pstmt.setString(5, row.getCell(4).getStringCellValue());
			            }else {
			            	pstmt.setString(5, null);
			            }
			            if(row.getCell(5) != null) {
			            	pstmt.setString(6, row.getCell(5).getStringCellValue());
			            }else {
			            	pstmt.setString(6, null);
			            }
		            pstmt.executeUpdate();  
					System.out.println("Insert Row " + i);
				}
				break;
				
			case "objects":	
				sheet = workbook.getSheetAt(2);
				rowCount = sheet.getLastRowNum();
				for (int i=1 ; i <= rowCount ; i++){
					row = sheet.getRow(i);
					sql = new StringBuffer();
					sql.append("INSERT INTO Objects(Primary_Objects , Object_Name, Object_Type, Locators, Properties, Page_ID) VALUES(?, ?, ?, ?, ?, ?)");
					pstmt = conn.prepareStatement(sql.toString());
					System.out.println(row.getCell(0).getStringCellValue());
					 pstmt.setString(1, row.getCell(0).getStringCellValue());
			         pstmt.setString(2, row.getCell(1).getStringCellValue());
			         pstmt.setString(3, row.getCell(2).getStringCellValue());
			         pstmt.setString(4, row.getCell(3).getStringCellValue());
			         pstmt.setString(5, row.getCell(4).getStringCellValue());
			         pstmt.setString(6, row.getCell(5).getStringCellValue());
			         pstmt.executeUpdate();  
						
					}
					break;
					
			case "pages":
				sql = new StringBuffer();
				sql.append("INSERT INTO Pages (Page_Name) VALUES ('CustomerCreation'), ('BuyOrder');");
				pstmt = conn.prepareStatement(sql.toString());
				pstmt.executeUpdate(); 
				break;
			default:
				break;
			}	
				
				
				
				
				
			
			conn.close();
			inputStream.close();
			
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
	    	
	    }
	    
	    
	    
	    
	    public static void insert() {  
	        String sql = "INSERT INTO Wrappers(GenericMethods) VALUES(?)";  
	   
	        try{  
	            Connection conn = connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);  
	            pstmt.setString(1, "enterInputText");  
	           
	            
	            pstmt.executeUpdate();  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	        
	        
	        
	    }  
	    
	    public static void delete() {  
	        String sql = "DELETE FROM ObjectDetails WHERE ObjectName ='call Object Extractor'";  
	   
	        try{  
	            Connection conn = connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);
	            pstmt.executeUpdate();  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	    }  
	    
	    
	    public static void selectAll(String userName){  
	        String sql = "SELECT * FROM authentication Where username = '" + userName + "'";  
	          
	        try {  
	            Connection conn = connect();  
	            Statement stmt  = conn.createStatement();  
	            ResultSet rs    = stmt.executeQuery(sql);  
	              
	            // loop through the result set  
	            while (rs.next()) {  
	                System.out.println(rs.getInt("id") +  "\t" +   
	                                   rs.getString("username") + "\t");  
	            }  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	    }  
	    
	    

}
