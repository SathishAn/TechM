package uiTool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class SQLite {
	
	 public static void createNewTable() {
		 
		 	
	        
	        String sql = "CREATE TABLE IF NOT EXISTS WrapperMethods(\n"
	                + "id integer PRIMARY KEY,\n"
	                + "methodname text NOT NULL,\n"
	                + "Parameter1 text NOT NULL,\n"
	                + "Parameter2 text NOT NULL,\n"
	                + "Parameter3 text NOT NULL,\n"
	                + "capacity real\n"
	                + ");";
	        
	        try {
	        	Connection conn = connect();	       
	            Statement stmt = conn.createStatement();	           
	            stmt.execute(sql);
	        } catch (SQLException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	 
	 
	 static Connection connect() {  
	        // SQLite connection string  
		 	String url = "jdbc:sqlite:D://sqlite/db/iEasyDB.db";  
	        Connection conn = null;  
	        try {  
	            conn = DriverManager.getConnection(url);  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	        return conn;  
	    }  
	 
	 
	 
	 
	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String[] args) {
	        createNewTable();
	        insert() ;
	        
	    }
	    
	    public static void insert() {  
	        String sql = "INSERT INTO WrapperMethods(methodname, Parameter1, Parameter2, Parameter3) VALUES(?, ?, ?, ?)";  
	   
	        try{  
	            Connection conn = connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);  
	            pstmt.setString(1, "invokeapp1");  
	            pstmt.setString(2, "String browser");
	            pstmt.setString(3, "String Url");
	            pstmt.setString(4, "");
	            pstmt.executeUpdate();  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	    }  
	    
	    
	    public static void selectAll(String userName){  
	        String sql = "SELECT * FROM authentication Where username = '" + userName + "'";  
	          
	        try {  
	            Connection conn = connect();  
	            Statement stmt  = conn.createStatement();  
	            ResultSet rs    = stmt.executeQuery(sql);  
	              
	            // loop through the result set  
	            while (rs.next()) {  
	                System.out.println(rs.getInt("id") +  "\t" +   
	                                   rs.getString("username") + "\t");  
	            }  
	        } catch (SQLException e) {  
	            System.out.println(e.getMessage());  
	        }  
	    }  
	    
	    

}
