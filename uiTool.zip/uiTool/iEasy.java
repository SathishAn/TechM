package uiTool;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.ItemSelectable;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultCellEditor;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayer;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.plaf.LayerUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import cucumber.api.java.en.Given;

public class iEasy extends JFrame implements ActionListener  {
	
	JLabel loginLabel,usernameLabel, passwordLabel ,smp;
	JButton sumbitBtn;
	JTextField usernameText;
	JPasswordField passwordText;
	Map<String, Boolean> wrapperMethods = new LinkedHashMap<String, Boolean>();
	Map<String, List<String>> wrapperParameter = new HashMap<String, List<String>>();
	
	public void iEasyTool() {
		// TODO Auto-generated constructor stub
		loginLabel = new JLabel("<html><font color='red'>i</font>EASY -  Automation</html>");        
		loginLabel.setFont(new Font("Serif", Font.BOLD, 20));		
		usernameLabel = new JLabel("User Name:");
		usernameText = new JTextField();
		passwordLabel = new JLabel("Password:");
		passwordText = new JPasswordField();
		sumbitBtn = new JButton("Submit");
		smp = new JLabel("Test");
		loginLabel.setBounds(250, 150, 400, 30);
		usernameLabel.setBounds(250, 200, 100, 30);
		usernameText.setBounds(350, 200, 200, 30);
		passwordLabel.setBounds(250, 240, 200, 30);
		passwordText.setBounds(350, 240, 200, 30);
		sumbitBtn.setBounds(250, 280, 100, 30);
        add(loginLabel);
        add(usernameLabel);
        add(usernameText);
        add(passwordLabel);
        add(passwordText);
        add(sumbitBtn);
        add(smp);
        sumbitBtn.addActionListener(this);
        setTitle("Login Form in Windows Form");
        setVisible(true);
        setSize(800, 800);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}   
        
    public void sample() throws IOException {
    	String sql = "SELECT * FROM authentication Where username = '" + usernameText.getText() +  "'";
		String userName = null, password = null;
		 try {  
		        Connection conn = SQLite.connect();  
		        Statement stmt  = conn.createStatement();  
		        ResultSet rs    = stmt.executeQuery(sql);  
		          
		        // loop through the result set  
		        while (rs.next()) { 
		        	
		        	userName = rs.getString("username"); 
		        	System.out.println(userName);
		        	password = rs.getString("password");
		        	break;
		        }  
		        
		        conn.close();
		        
		        if(userName.equals(usernameText.getText()) && password.equals(passwordText.getText())) {
		        	System.out.println("Login success");
		        	dispose();
		        	iEasyToolExecutor();
		        }else {
		        	System.out.println("Login Failed");
		        }
		        
		    } catch (SQLException e1) {  
		        System.out.println(e1.getMessage());  
		    }
    }

	
	
	public static Map<String, String> readObjects() {
		Map<String, String> identifiedObjects = new TreeMap<String, String>();
		identifiedObjects.put("1. Please Select", "Please Select");
		try {
			String path = "./src/test/resources/Datatable/accelator.xlsx";
			
			File file = new File(path);
			FileInputStream inputStream;
			inputStream = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum();
			System.out.println(rowCount);
			Row row = sheet.getRow(0);
			int colCount = row.getLastCellNum();
			for (int i = 1; i <= rowCount; i++) {
				row = sheet.getRow(i);
				identifiedObjects.put(row.getCell(0).getStringCellValue(), row.getCell(1).getStringCellValue());
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return identifiedObjects;
	}
	
	
	public  JFrame iEasyFrame,  methodFrame;
	public  JPanel headerPanel, explorerPanel, stepCreationPanel, messageAreaPanel, stepDefPanel,objectExtractPanel;
	public  JTextArea stepdefTextArea, messageText;
	public  JButton addStepButton, createStepDefButton, closeTabButton, addMethodButton, addWrapperMethods;
	public  JTree explorerTree;
	public   JTabbedPane tabPane;
	public  JComboBox keywordBDDCombo,  objectCombo, bddListCombo;
	public  JTextField bddText;
	public JPopupMenu methodPopup;
	
	public void iEasyToolExecutor() {
		iEasyFrame = new JFrame("iEasy - Automation");
		
		iEasyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		iEasyFrame.setSize(800,600);
		messageAreaPanel =  new JPanel();
		messageText = new JTextArea();
		messageAreaPanel.add(messageText);
		//To design the header panel
		iEasyHeader();
		//To design the explorer panel
		explorerPanel();
		//
		tabPanel();
		
		
		iEasyFrame.getContentPane().add(BorderLayout.NORTH, headerPanel);
		iEasyFrame.getContentPane().add(BorderLayout.WEST, explorerPanel);	        
		iEasyFrame.getContentPane().add(BorderLayout.SOUTH, messageAreaPanel);
	    iEasyFrame.add(tabPane);	        
	    explorerPanel.setPreferredSize(new Dimension(150, 500));
	    messageAreaPanel.setPreferredSize(new Dimension(10, 50)); 	        
	       
	    iEasyFrame.setExtendedState(iEasyFrame.getExtendedState() | JFrame.MAXIMIZED_BOTH);	        
	    iEasyFrame.setVisible(true);
		
	}
	
	
	
	public void iEasyHeader() {
		headerPanel = new JPanel();
		JLabel titleLabel = new JLabel("<html><font color='red'>i</font>EASY -  Automation</html>");
		Font font = new Font("Courier", Font.BOLD, 28);
		titleLabel.setFont(font);
		headerPanel.add(titleLabel);		 
	}
	
	
	public void explorerPanel() {
		explorerPanel = new JPanel();
		DefaultMutableTreeNode iEasy = new DefaultMutableTreeNode("iEasy");
		DefaultMutableTreeNode objectExtractor = new DefaultMutableTreeNode("ObjectExtractor");
		DefaultMutableTreeNode StepDef = new DefaultMutableTreeNode("StepDefination");
		iEasy.add(objectExtractor);
		iEasy.add(StepDef);
		
		explorerTree = new JTree(iEasy);
		explorerPanel.add(explorerTree);
		explorerTree.setBounds(1, 10, 148, 600);
		explorerPanel.setBackground(new Color(0, 255, 0, 0));
		explorerPanel.setLayout(null);
		explorerTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				boolean bTabFlag = false;
				String tabName= null;
				JPanel panelName = null;
				TreePath tp = explorerTree.getPathForLocation(me.getX(), me.getY());
			    System.out.println(tp.toString());			     
				String action = tp.toString();
				switch (action) {
				case "[iEasy, StepDefination]":
									
					stepDefinationPanel();
					tabName = "StepDef";
					panelName= stepDefPanel;
					bTabFlag = true;
					
					

					break;					
				case "[iEasy, ObjectExtractor]":	
					objectExtractorPanel();
					bTabFlag = true;
					tabName = "ObjectExtractor";
					panelName= objectExtractPanel;
					bTabFlag = true;
					break;
					
				default:
					break;
				}
				
				if(bTabFlag) {
					boolean bFlag = false;	
					for(int i = 0 ; i<tabPane.getTabCount(); i++ ) {
						System.out.println(tabPane.getTitleAt(i));
						if(tabPane.getTitleAt(i).equals(tabName)) {
							bFlag = true;
							break;
						}
					}
					if(!bFlag) {
						tabPane.addTab("StepDef", panelName);
						tabPane.setSelectedIndex(tabPane.getTabCount()-1);
					}
				}
				

			}
		});
		
	}
	
	
	public void tabPanel() {
		 tabPane = new JTabbedPane();
		 JPanel homePanel = new JPanel();
		 tabPane.addTab("Home", homePanel);
	}
	
	
	
	
	
	public void stepDefinationPanel() {
		Object[] objectList= readObjects().keySet().toArray();
		Object[] bddList = getListFromDB("ScenarioList").toArray();
		//Object[] methodList = getListFromDB("MethodList").toArray();
		String keyWordBDD[] = { "Given", "When", "And", "Then" };
		stepDefPanel = new JPanel();
		JLabel scenarioLabel = new JLabel("Scenario Step:");
		keywordBDDCombo = new JComboBox(keyWordBDD);
		bddText = new JTextField(200);
		JLabel objectLabel = new JLabel("Select Object");
		objectCombo = new JComboBox(objectList);
		addWrapperMethods  = new JButton("Add Method");		
		addStepButton = new JButton("+");
		stepdefTextArea = new JTextArea();
		JScrollPane textpane = new JScrollPane(stepdefTextArea);
		textpane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		textpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		createStepDefButton = new JButton("Create");
		bddListCombo = new JComboBox(bddList);
		closeTabButton= new JButton("Close");
		scenarioLabel.setBounds(10, 10, 100, 30);
		keywordBDDCombo.setBounds(100, 10, 100, 30);
		bddText.setBounds(220, 10, 500, 30);
		addStepButton.setBounds(260, 45, 100, 30);
		addWrapperMethods.setBounds(380, 45, 100, 30);		
		objectLabel.setBounds(10, 45, 100, 30);
		objectCombo.setBounds(100, 45, 150, 30);
		textpane.setBounds(20, 95, 600, 200);
		createStepDefButton.setBounds(20, 295, 100, 30);
		bddListCombo.setBounds(20, 350, 500, 30);
		closeTabButton.setBounds(60, 500, 100, 30);
		stepDefPanel.add(scenarioLabel);
        stepDefPanel.add(keywordBDDCombo);
        stepDefPanel.add(addWrapperMethods);
        stepDefPanel.add(bddText);
        stepDefPanel.add(addStepButton);        
        stepDefPanel.add(objectLabel);
        stepDefPanel.add(objectCombo);
        stepDefPanel.add(textpane);
        stepDefPanel.add(createStepDefButton);
        stepDefPanel.add(bddListCombo);
        stepDefPanel.add(closeTabButton);
        stepDefPanel.setLayout(null);
        addStepButton.addActionListener(this);
        addWrapperMethods.addActionListener(this);
        createStepDefButton.addActionListener(this);
        closeTabButton.addActionListener(this);
			
				// TODO Auto-generated method stub
				
	     
	}
	
	
	public void objectExtractorPanel() {
		Object[] bddList = getListFromDB("ScenarioList").toArray();
		JLabel scenarioLabel = new JLabel("BDD Scenario List:");
		bddListCombo = new JComboBox(bddList);
		addStepButton = new JButton("+");
		stepdefTextArea = new JTextArea();
		JScrollPane textpane = new JScrollPane(stepdefTextArea);
		textpane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		textpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scenarioLabel.setBounds(10, 10, 100, 30);
		bddListCombo.setBounds(220, 10, 500, 30);
		textpane.setBounds(20, 95, 600, 200);
		objectExtractPanel = new JPanel();
		objectExtractPanel.add(scenarioLabel);
		objectExtractPanel.add(bddListCombo);
		objectExtractPanel.add(addStepButton);
		objectExtractPanel.add(textpane);
		objectExtractPanel.setLayout(null);
	}
	
	
	
	
	public void actionPerformed(ActionEvent eve) {
		String data, value;
		
		if(eve.getSource() == addStepButton) {
			String result = null;
			data = (String) objectCombo.getItemAt(objectCombo.getSelectedIndex());
			objectCombo.removeItemAt(objectCombo.getSelectedIndex());
			value = stepdefTextArea.getText();
			if (value.isEmpty()) {
				result = "T24.enter_" + data + "();";
			} else {
				result = value + "\n" + "T24.enter_" + data + "();";
			}

			stepdefTextArea.setText(result);
			
			
			
			
		}else if (eve.getSource() == createStepDefButton) {
			data = (String) keywordBDDCombo.getItemAt(keywordBDDCombo.getSelectedIndex());
			value = bddText.getText();
			System.out.println(data + " " + value);
			if(!stepdefTextArea.getText().isEmpty()) {
				String methodName = bddStepDefinationGeneration(data ,value, stepdefTextArea.getText());
				messageText.setText(insert(value, data, methodName, stepdefTextArea.getText()));
				bddListCombo.addItem(data + " " + value);
				
				
				stepdefTextArea.setText("");
			}else {
				messageText.setText("Please add step defination");
			}
			
			
			
			
		}else if (eve.getSource() == closeTabButton) {
			tabPane.remove(tabPane.getSelectedIndex());
			
		}else if(eve.getSource() == addMethodButton) {
			String methods = "";
			for(String key : wrapperMethods.keySet()) {
				if(wrapperMethods.get(key)) {
					String parameter = null;
					List<String> Temp = wrapperParameter.get(key);
					for(String param: Temp) {
						if(!param.isEmpty()) {
							if(parameter == null) {
								parameter =  param;
							}else {
								parameter = parameter + ","+ param;
							}
							
						}
					}
					methods = key + "(" + parameter + ")";
				}
			}
			stepdefTextArea.setText(methods);
			System.out.println(methods);
			
			 methodFrame.dispose();
			 
			
		}else if(eve.getSource() == addWrapperMethods) {
			methodList();
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	 public static String insert(String scenarioName, String scenarioKey, String methodName, String Method) {  
	        String sql = "INSERT INTO scenarioList(scenarioName, scenarioKey, methodName, methodBody) VALUES(?,?,?,?)";  
	        String message = null;
	        try{  
	            Connection conn = SQLite.connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);  
	            pstmt.setString(1, scenarioName);
	            pstmt.setString(2, scenarioKey);
	            pstmt.setString(3, methodName);
	            pstmt.setString(4, Method);
	            pstmt.executeUpdate();  
	            conn.close();
	           message = "Success - Insert Successfully";
	        } catch (SQLException e) {  
	            message = "Failed - Unable to add the scenario" + e.getMessage();
	        }
	        System.out.println(message);
			return message;  
	    } 
	 
	 
	 public ArrayList<ArrayList<String>> methodListValue; 
	 public ArrayList<String> getListFromDB(String listType) {		 
		 ArrayList<String> arrList = new ArrayList<String>();
		 String sql = null ;
		 try {
		 Connection conn = SQLite.connect();  
		 Statement stmt  = conn.createStatement();
		 ResultSet rs;
		 switch (listType.toLowerCase()) {
		case "scenariolist":
			sql = "SELECT * FROM scenarioList";
			rs = stmt.executeQuery(sql);		 
			while(rs.next()) {
				System.err.println(rs.getString("scenarioName"));
				arrList.add(rs.getString("scenarioKey") + " " + rs.getString("scenarioName"));
			 }
			break;
		case "methodlist":
			sql = "SELECT * FROM WrapperMethods";
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd =  rs.getMetaData();
			methodListValue= new ArrayList<>(rsmd.getColumnCount());
			
			for(int i =1; i< rsmd.getColumnCount(); i++) {
				System.err.println(rsmd.getColumnName(i));
				arrList.add(rsmd.getColumnName(i));
				methodListValue.add(new ArrayList<String>());
			}	
			arrList.add("SelectOptions");
			
			
			while(rs.next()) {
				for(int i =1; i< rsmd.getColumnCount(); i++) {					
					methodListValue.get(i-1).add(rs.getString(i));
				}				
				
				
			 }
			
		default:
			break;
		}	
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return arrList;
		 
	 }
	 
	
	 public void methodList() {
		try {

			methodFrame = new JFrame();
			JPanel tablePanel = new JPanel();
			Object[] column = getListFromDB("MethodList").toArray();
			int rsize = methodListValue.size();
			int csize = methodListValue.get(0).size();
			System.out.println("Row Size :" + rsize);
			System.out.println("Column Size :" + csize);

			Object data[][] = new Object[csize][rsize + 1];
			for (int j = 0; j < csize; j++) {
				for (int i = 0; i < rsize; i++) {
					if (i == rsize) {
						data[j][i] = Boolean.FALSE;
					} else {
						System.out.println(methodListValue.get(i).get(j).toString());
						data[j][i] = methodListValue.get(i).get(j).toString();
					}
				}
			}
			JTable jt = new JTable(data, column);
			JCheckBox checkbox;
			jt.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(checkbox = new JCheckBox()));
			jt.getColumnModel().getColumn(5).setPreferredWidth(10);

			jt.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
				JCheckBox checkBox = new JCheckBox();

				public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
						boolean hasFocus, int row, int column) {
					checkBox.setBackground(isSelected ? UIManager.getColor("Table.selectionBackground")
							: UIManager.getColor("Table.background"));
					checkBox.setSelected(Boolean.TRUE.equals(value));
					return checkBox;
				}
			});
			checkbox.addItemListener(new ItemListener() {
				@Override
				public void itemStateChanged(ItemEvent e) {
					System.out.println("Check box state " + e.getStateChange());
				}
			});
			jt.getModel().addTableModelListener(new TableModelListener() {
				@Override
				public void tableChanged(TableModelEvent e) {
					int row = jt.getSelectedRow();
					int column = 1;
					String cellValue = String.valueOf(jt.getValueAt(row, column));
					String cellStatus = String.valueOf(jt.getValueAt(row, 5));
					System.out.println(cellValue + cellStatus);
					wrapperMethods.put(cellValue, Boolean.valueOf(cellStatus));
					List<String> param = new ArrayList<>();
					for (int i = 2; i < jt.getColumnCount()-1; i++) {
						
						param.add(String.valueOf(jt.getValueAt(row, i)));
					}
					wrapperParameter.put(cellValue, param);
					
				}
			});

			
			JScrollPane sp = new JScrollPane(jt);
			tablePanel.add(sp);
			sp.setBounds(1, 5, 800, 300);			
			addMethodButton = new JButton("Add");
			addMethodButton.setBounds(10, 350, 100, 30);
			addMethodButton.addActionListener(this);
			//sp.add(addMethodButton);
			tablePanel.add(addMethodButton);
			tablePanel.setLayout(null);
			
			methodFrame.add(tablePanel);
			methodFrame.setSize(820, 500);				  
			methodFrame.setVisible(true);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
		 
		 
	 
	 
	 
	 
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//new iEasy();
		iEasy es = new iEasy();
		es.iEasyToolExecutor();
		
	        
	}
	
	public static String bddStepDefinationGeneration(String Bdd, String Tempvalue, String methods) {
		String combinedText = null, methodName = null;
		String[] scenarios = Tempvalue.split("\"");
		int count = 0;
		for(int i=0; i <= scenarios.length; i=i+2)
		{					
			
			if (combinedText == null) {
				combinedText = scenarios[i] ;
				methodName = scenarios[i].trim();
				count++;
			}else {
				combinedText = combinedText + "\\\"([^\\\"]*)\\\"" + scenarios[i] ;
				methodName = methodName +  scenarios[i] ;
				count++;
			}
			
		}
							
		System.err.println("@" + Bdd + "(\"^" + combinedText +"$\")");
		String parameter = "";
		for(int i = 1; i< count; i++) {
			if(parameter.isEmpty()) {
				parameter = "String arg"+i;
			}else {
				parameter = parameter +  ",String arg"+i; 
			}
			
		}
		System.err.println(methodName.replaceAll(" ", "_") + "(" +parameter+ "){\n " + methods + " \n}");
		return combinedText;
		
	 
		
	}


	


	

	
		
	

}
