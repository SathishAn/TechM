package uiTool;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.BorderFactory;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayer;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.plaf.LayerUI;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class iEasy extends JFrame implements ActionListener  {
	
	JLabel loginLabel,usernameLabel, passwordLabel ,smp;
	JButton sumbitBtn;
	JTextField usernameText;
	JPasswordField passwordText;
	
	public void iEasyTool() {
		// TODO Auto-generated constructor stub
		loginLabel = new JLabel("<html><font color='red'>i</font>EASY -  Automation</html>");        
		loginLabel.setFont(new Font("Serif", Font.BOLD, 20));		
		usernameLabel = new JLabel("User Name:");
		usernameText = new JTextField();
		passwordLabel = new JLabel("Password:");
		passwordText = new JPasswordField();
		sumbitBtn = new JButton("Submit");
		smp = new JLabel("Test");
		loginLabel.setBounds(250, 150, 400, 30);
		usernameLabel.setBounds(250, 200, 100, 30);
		usernameText.setBounds(350, 200, 200, 30);
		passwordLabel.setBounds(250, 240, 200, 30);
		passwordText.setBounds(350, 240, 200, 30);
		sumbitBtn.setBounds(250, 280, 100, 30);
        add(loginLabel);
        add(usernameLabel);
        add(usernameText);
        add(passwordLabel);
        add(passwordText);
        add(sumbitBtn);
        add(smp);
        sumbitBtn.addActionListener(this);
        setTitle("Login Form in Windows Form");
        setVisible(true);
        setSize(800, 800);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}   
        
    public void sample() throws IOException {
    	String sql = "SELECT * FROM authentication Where username = '" + usernameText.getText() +  "'";
		String userName = null, password = null;
		 try {  
		        Connection conn = SQLite.connect();  
		        Statement stmt  = conn.createStatement();  
		        ResultSet rs    = stmt.executeQuery(sql);  
		          
		        // loop through the result set  
		        while (rs.next()) { 
		        	
		        	userName = rs.getString("username"); 
		        	System.out.println(userName);
		        	password = rs.getString("password");
		        	break;
		        }  
		        
		        conn.close();
		        
		        if(userName.equals(usernameText.getText()) && password.equals(passwordText.getText())) {
		        	System.out.println("Login success");
		        	dispose();
		        	iEasyToolExecutor();
		        }else {
		        	System.out.println("Login Failed");
		        }
		        
		    } catch (SQLException e1) {  
		        System.out.println(e1.getMessage());  
		    }
    }

	

	
	
	
	
	
	public static Map<String, String> readObjects() {
		Map<String, String> identifiedObjects = new TreeMap<String, String>();
		try {
			String path = "D:/CBA_Framework/Core-Banking_v1.0/src/test/resources/datatable/accelator.xlsx";
			
			File file = new File(path);
			FileInputStream inputStream;
			inputStream = new FileInputStream(file);
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheetAt(0);
			int rowCount = sheet.getLastRowNum();
			System.out.println(rowCount);
			Row row = sheet.getRow(0);
			int colCount = row.getLastCellNum();
			for (int i = 1; i <= rowCount; i++) {
				row = sheet.getRow(i);
				identifiedObjects.put(row.getCell(0).getStringCellValue(), row.getCell(1).getStringCellValue());
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return identifiedObjects;
	}
	
	
	public  JFrame iEasyFrame;
	public  JPanel headerPanel, explorerPanel, stepCreationPanel, messageAreaPanel, stepDefPanel;
	public  JTextArea stepdefTextArea, messageText;
	public  JButton addStepButton, createStepDefButton, closeTabButton;
	public  JTree explorerTree;
	public   JTabbedPane tabPane;
	public  JComboBox keywordBDDCombo,  objectCombo, bddListCombo;
	public  JTextField bddText;
	
	public void iEasyToolExecutor() {
		iEasyFrame = new JFrame("iEasy - Automation");
		iEasyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		iEasyFrame.setSize(800,600);
		messageAreaPanel =  new JPanel();
		messageText = new JTextArea();
		messageAreaPanel.add(messageText);
		//To design the header panel
		iEasyHeader();
		//To design the explorer panel
		explorerPanel();
		//
		tabPanel();
		
		
		iEasyFrame.getContentPane().add(BorderLayout.NORTH, headerPanel);
		iEasyFrame.getContentPane().add(BorderLayout.WEST, explorerPanel);	        
		iEasyFrame.getContentPane().add(BorderLayout.SOUTH, messageAreaPanel);
	    iEasyFrame.add(tabPane);
	        
	    explorerPanel.setPreferredSize(new Dimension(150, 500));
	    messageAreaPanel.setPreferredSize(new Dimension(10, 50));    
	        
	       
	    iEasyFrame.setExtendedState(iEasyFrame.getExtendedState() | JFrame.MAXIMIZED_BOTH);	        
	    iEasyFrame.setVisible(true);
		
	}
	
	
	
	public void iEasyHeader() {
		headerPanel = new JPanel();
		JLabel titleLabel = new JLabel("<html><font color='red'>i</font>EASY -  Automation</html>");
		Font font = new Font("Courier", Font.BOLD, 28);
		titleLabel.setFont(font);
		headerPanel.add(titleLabel);		 
	}
	
	
	public void explorerPanel() {
		explorerPanel = new JPanel();
		DefaultMutableTreeNode iEasy = new DefaultMutableTreeNode("iEasy");
		DefaultMutableTreeNode objectExtractor = new DefaultMutableTreeNode("ObjectExtractor");
		DefaultMutableTreeNode StepDef = new DefaultMutableTreeNode("StepDefination");
		iEasy.add(objectExtractor);
		iEasy.add(StepDef);
		
		explorerTree = new JTree(iEasy);
		explorerPanel.add(explorerTree);
		explorerTree.setBounds(1, 10, 148, 600);
		explorerPanel.setBackground(new Color(0, 255, 0, 0));
		explorerPanel.setLayout(null);
		explorerTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				String action = doMouseClicked(me);
				switch (action) {
				case "[iEasy, StepDefination]":
					boolean bFlag = false;
					int selectedIndex = tabPane.getSelectedIndex();
					System.out.println("Default Index:" + selectedIndex);
					stepDefinationPanel();
					System.out.println("Tabpane :" + tabPane.getTabCount());
					for(int i = 0 ; i<tabPane.getTabCount(); i++ ) {
						System.out.println(tabPane.getTitleAt(i));
						if(tabPane.getTitleAt(i).equals("StepDef")) {
							bFlag = true;
							break;
						}
					}
					if(!bFlag) {
						tabPane.addTab("StepDef", stepDefPanel);
						tabPane.setSelectedIndex(tabPane.getTabCount()-1);
					}
					

					break;
					
				default:
					break;
				}

			}
		});
		
	}
	
	
	public void tabPanel() {
		 tabPane = new JTabbedPane();
		 JPanel homePanel = new JPanel();
		 tabPane.addTab("Home", homePanel);
	}
	
	
	
	
	
	public void stepDefinationPanel() {
		Object[] objectList = readObjects().keySet().toArray();
		Object[] bddList = getScenarioList().toArray();
		String keyWordBDD[] = { "Given", "When", "And", "Then" };
		stepDefPanel = new JPanel();
		JLabel scenarioLabel = new JLabel("Scenario Step:");
		keywordBDDCombo = new JComboBox(keyWordBDD);
		bddText = new JTextField(200);
		JLabel objectLabel = new JLabel("Select Object");
		objectCombo = new JComboBox(objectList);
		addStepButton = new JButton("+");
		stepdefTextArea = new JTextArea();
		JScrollPane textpane = new JScrollPane(stepdefTextArea);
		textpane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		textpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		createStepDefButton = new JButton("Create");
		bddListCombo = new JComboBox(bddList);
		closeTabButton= new JButton("Close");
		scenarioLabel.setBounds(10, 10, 100, 30);
		keywordBDDCombo.setBounds(100, 10, 100, 30);
		bddText.setBounds(220, 10, 500, 30);
		addStepButton.setBounds(260, 45, 100, 30);
		objectLabel.setBounds(10, 45, 100, 30);
		objectCombo.setBounds(100, 45, 150, 30);
		textpane.setBounds(20, 95, 600, 200);
		createStepDefButton.setBounds(20, 295, 100, 30);
		bddListCombo.setBounds(20, 350, 500, 30);
		closeTabButton.setBounds(60, 500, 100, 30);
		stepDefPanel.add(scenarioLabel);
        stepDefPanel.add(keywordBDDCombo);
        stepDefPanel.add(bddText);
        stepDefPanel.add(addStepButton);        
        stepDefPanel.add(objectLabel);
        stepDefPanel.add(objectCombo);
        stepDefPanel.add(textpane);
        stepDefPanel.add(createStepDefButton);
        stepDefPanel.add(bddListCombo);
        stepDefPanel.add(closeTabButton);
        stepDefPanel.setLayout(null);
        addStepButton.addActionListener(this);
        createStepDefButton.addActionListener(this);
        closeTabButton.addActionListener(this);
			
				// TODO Auto-generated method stub
				
	     
	}
	
	
	
	
	public void actionPerformed(ActionEvent eve) {
		String data, value;
		
		if(eve.getSource() == addStepButton) {
			String result = null;
			data = (String) objectCombo.getItemAt(objectCombo.getSelectedIndex());
			objectCombo.removeItemAt(objectCombo.getSelectedIndex());
			value = stepdefTextArea.getText();
			if (value.isEmpty()) {
				result = "T24.enter_" + data + "();";
			} else {
				result = value + "\n" + "T24.enter_" + data + "();";
			}

			stepdefTextArea.setText(result);
		}else if (eve.getSource() == createStepDefButton) {
			data = (String) keywordBDDCombo.getItemAt(keywordBDDCombo.getSelectedIndex());
			value = bddText.getText();
			System.out.println(data + " " + value);
			messageText.setText(insert(data + " " + value));
			bddListCombo.addItem(data + " " + value);
			
		}else if (eve.getSource() == closeTabButton) {
			tabPane.remove(tabPane.getSelectedIndex());
		}
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	 String doMouseClicked(MouseEvent me) {
	    TreePath tp = explorerTree.getPathForLocation(me.getX(), me.getY());
	    System.out.println(tp.toString());
	    return tp.toString();
	  }
	
	
	 public static String insert(String value) {  
	        String sql = "INSERT INTO scenario(scenarioName) VALUES(?)";  
	        String message = null;
	        try{  
	            Connection conn = SQLite.connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);  
	            pstmt.setString(1, value);
	             
	            pstmt.executeUpdate();  
	            conn.close();
	           message = "Success - Insert Successfully";
	        } catch (SQLException e) {  
	            message = "Failed - Unable to add the scenario";
	        }
	        System.out.println(message);
			return message;  
	    } 
	 
	 
	 
	 public static ArrayList<String> getScenarioList() {
		 ArrayList<String> arrList = new ArrayList<String>();
		 String sql = "SELECT * FROM scenario";
		 Connection conn = SQLite.connect();  
         try {
			Statement stmt  = conn.createStatement();	
			ResultSet rs = stmt.executeQuery(sql);		 
			while(rs.next()) {
				System.err.println(rs.getString("scenarioName"));
				arrList.add(rs.getString("scenarioName"));
			 }
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return arrList;
		 
	 }
	 
	 
	 
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//new iEasy();
		iEasy es = new iEasy();
		es.iEasyToolExecutor();
		
	        
	}
	
	public static void bddGeneration(String value) {
		String combinedText = null;
		String[] scenarios = value.split("\"");
		for(int i=0; i <= scenarios.length; i=i+2)
		{					
			
			if (combinedText == null) {
				combinedText = scenarios[i] ;
			}else {
				combinedText = combinedText + "\\\"([^\\\"]*)\\\"" + scenarios[i] ;
			}
			
		}
							
		System.err.println(combinedText);
		
	 
		
	}





	

	
		
	

}
