package uiTool;

import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.ItemSelectable;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayer;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.plaf.LayerUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import cucumber.api.java.en.Given;

public class iEasy2 extends JFrame implements ActionListener, TableModelListener  {
	
	Map<String, Boolean> iBuildInMethodsMap  = new LinkedHashMap<String, Boolean>();
	Map<String, Boolean> iAppliactionMethodsMap  = new LinkedHashMap<String, Boolean>();
	Map<String, String> iAppMethodParameterMap  = new HashMap<String, String>();
	Map<String, List<String>> iBuiltInParameter = new HashMap<String, List<String>>();
	public String iObjectOptions = null;
	public ArrayList<ArrayList<String>> methodListValue;
	public String iSelectedPageName;
	public JPanel iAppMethodsPanel;
	public JRadioButton iAddObjects_Rbtn, iExistingObject_Rbtn, iNewMethod_Rbtn; 
	public JScrollPane iObjectScrollPane;
	public JFrame iEasyFrame,  iBuiltInMethodFrame, iAppMethodFrame;
	public JPanel headerPanel, explorerPanel, stepCreationPanel, messageAreaPanel, iStepDefinationPanel,objectExtractPanel, iPagesPanel;
	public JTextArea  messageText, bddScriptTextArea;
	public JButton okDialogbutton, iAppMethodsbtn, addStepButton, addBddButton,addObjectCallButton , BddExeuteButton , closeTabButton;
	public JButton iBuiltInBtn, iBuildInMethodAddbtn, iMoveUpbtn, iMoveDownbtn, iPageViewbtn, iAppMethodAddbtn,
			iCreateStepDefbtn, iAddObjectsbtn, iInsertObjectsbtn, iDeleteObjectbtn, iUpdateObjectsbtn;
	
	public JTree explorerTree;
	public JTabbedPane tabPane;
	public JComboBox iKeywordBDDCmbBox,  bddListCombo, bddListObjectCombo, iPageNameCmbBox;
	public JTextField iBDDText, pageNameText;
	public JPopupMenu methodPopup;
	public DefaultListModel<String> iStepListModel;
	public JList<String> iStepListbox;
	public DefaultTableModel iAppModelTable, iObjectModelTable ;
	public JTable iAppMethodTable, iBuiltInTable, iAddObjectTable;
	
	// iEasy UI Frame
	
	public void iEasyToolExecutor() {
		// JFrame.setDefaultLookAndFeelDecorated(true); 
		iEasyFrame = new JFrame("iEasy - Automation");		
		iEasyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		iEasyFrame.setSize(800,600);		
		messageAreaPanel =  new JPanel();
		messageText = new JTextArea();
		messageAreaPanel.add(messageText);
		//To design the header panel
		iEasyHeader();
		//To design the explorer panel
		explorerPanel();
		//TabPanel
		tabPanel();
		 /*String LAF; 
		 LAF = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
		 try {
	         UIManager.setLookAndFeel(LAF);
	         SwingUtilities.updateComponentTreeUI(iEasyFrame);
	      } catch (Exception e) {
	         System.out.println("Error setting the LAF..." + e);
	      }
		 */
		iEasyFrame.getContentPane().add(BorderLayout.NORTH, headerPanel);
		iEasyFrame.getContentPane().add(BorderLayout.WEST, explorerPanel);	        
		iEasyFrame.getContentPane().add(BorderLayout.SOUTH, messageAreaPanel);
	    iEasyFrame.add(tabPane);	        
	    explorerPanel.setPreferredSize(new Dimension(150, 500));
	    messageAreaPanel.setPreferredSize(new Dimension(10, 50));
	    
	    iEasyFrame.setExtendedState(iEasyFrame.getExtendedState() | JFrame.MAXIMIZED_BOTH);	 
	    iEasyFrame.setBackground(Color.RED);
	    iEasyFrame.setVisible(true);
		
	}
	
	
	
	
	public void iEasyHeader() {
		headerPanel = new JPanel();  
		JLabel titleLabel = new JLabel("<html><font color='red'>i</font>EASY -  Automation</html>");
		Font font = new Font("Courier", Font.BOLD, 28);
		titleLabel.setFont(font);
		headerPanel.add(titleLabel);		 
	}
	
	
	public void explorerPanel() {
		explorerPanel = new JPanel();
		DefaultMutableTreeNode iEasy = new DefaultMutableTreeNode("iEasy");
		DefaultMutableTreeNode objectExtractor = new DefaultMutableTreeNode("ObjectExtractor");
		DefaultMutableTreeNode StepDef = new DefaultMutableTreeNode("StepDefination");
		DefaultMutableTreeNode iPageObjects = new DefaultMutableTreeNode("PageObjects");
		DefaultMutableTreeNode Features = new DefaultMutableTreeNode("BDD");
		DefaultMutableTreeNode createNewFeatures = new DefaultMutableTreeNode("Create New");
		DefaultMutableTreeNode AppendFeatures = new DefaultMutableTreeNode("Append");
		iEasy.add(iPageObjects);
		iEasy.add(objectExtractor);		
		iEasy.add(StepDef);
		
		Features.add(createNewFeatures);
		Features.add(AppendFeatures);
		iEasy.add(Features);
		explorerTree = new JTree(iEasy);
		explorerPanel.add(explorerTree);
		explorerTree.setBounds(1, 10, 148, 600);
		explorerPanel.setBackground(new Color(0, 255, 0, 0));
		explorerPanel.setLayout(null);
		explorerTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				boolean bTabFlag = false;
				String tabName= null;
				JPanel panelName = null;
				TreePath tp = explorerTree.getPathForLocation(me.getX(), me.getY());
				
				String action = tp.toString();
				switch (action) {
				case "[iEasy, StepDefination]":
									
					createStepDefinationPanel();
					tabName = "StepDef";
					panelName= iStepDefinationPanel;
					bTabFlag = true;
					
					

					break;					
				case "[iEasy, ObjectExtractor]":	
					objectExtractorPanel();
					bTabFlag = true;
					tabName = "ObjectExtractor";
					panelName= objectExtractPanel;
					bTabFlag = true;
					break;
					
				case "[iEasy, PageObjects]":	
					iPageViewModificationPanel();
					bTabFlag = true;
					tabName = "PageObjects";
					panelName= iPagesPanel;
					bTabFlag = true;
					break;	
					
				default:
					break;
				}
				
				if(bTabFlag) {
					boolean bFlag = false;	
					for(int i = 0 ; i<tabPane.getTabCount(); i++ ) {
						System.out.println(tabPane.getTitleAt(i));
						if(tabPane.getTitleAt(i).equals(tabName)) {
							bFlag = true;
							break;
						}
					}
					if(!bFlag) {
						tabPane.addTab(tabName, panelName);
						tabPane.setSelectedIndex(tabPane.getTabCount()-1);
					}
				}
				

			}
		});
		
	}
	
	
	public void tabPanel() {
		String homeText = "iEASY is a Automation Framework build using Selenium with Behavior Driven Development (BDD) Cucumber\n "
				+ "and TestNG Framework aimed at reducing test execution effort and increase automation test scripts design\n "
				+ "productivity.\r\n";
		tabPane = new JTabbedPane();
		JPanel homePanel = new JPanel();
		JTextPane homeTextArea = new JTextPane();

		homeTextArea.setBounds(1, 1, 800, 500);
		SimpleAttributeSet attributeSet = new SimpleAttributeSet();
		StyleConstants.setBold(attributeSet, true);

		// Set the attributes before adding text
		homeTextArea.setCharacterAttributes(attributeSet, true);
		homeTextArea.setText(homeText);
		homeTextArea.setEnabled(false);
		homePanel.add(homeTextArea);
		homePanel.setLayout(null);
		tabPane.addTab("Home", homePanel);
	}
	
	
	public void iSwapStepList(int a, int b) {
		String aObject = iStepListModel.getElementAt(a);
		String bObject = iStepListModel.getElementAt(b);
		iStepListModel.set(b, aObject);
		iStepListModel.set(a, bObject);
		iStepListbox.setSelectedIndex(b);
	}
	
	
	public void iPageViewModificationPanel() {
		iPagesPanel = new JPanel();
		
	}
	
	
	
	
	
	public void createStepDefinationPanel() {
		Object[] iObjectList= getListFromDB("objectlist").toArray();
		Object[] iBDDList = getListFromDB("ScenarioList").toArray();		
		String iKeyWordBDD[] = { "Given", "When", "And", "Then" };
		iStepDefinationPanel = new JPanel();
		JLabel iScenarioLabel = new JLabel("Scenario Step:");
		iKeywordBDDCmbBox = new JComboBox(iKeyWordBDD);
		iBDDText = new JTextField(200);
		iAppMethodsbtn= new JButton("Appliaction Methods");
		iBuiltInBtn  = new JButton("Buildin..");
		iStepListModel = new DefaultListModel<>();		
		iStepListbox = new JList<>(iStepListModel);
		JScrollPane iScrollPane = new JScrollPane(iStepListbox);
		iScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		iScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		iMoveUpbtn = new JButton("Up");
		iMoveDownbtn = new JButton("Down");
		
		iCreateStepDefbtn = new JButton("Create");
		bddListCombo = new JComboBox(iBDDList);
		closeTabButton= new JButton("Close");
		iScenarioLabel.setBounds(20, 10, 100, 30);
		iKeywordBDDCmbBox.setBounds(120, 10, 100, 30);
		iBDDText.setBounds(240, 10, 500, 30);
		iAppMethodsbtn.setBounds(120, 55, 150, 30);
		iBuiltInBtn.setBounds(280, 55, 100, 30);
		iScrollPane.setBounds(20, 95, 600, 200);
		iMoveUpbtn.setBounds(650, 105, 100, 30);
		iMoveDownbtn.setBounds(650, 145, 100, 30);
		
		iCreateStepDefbtn.setBounds(20, 315, 100, 30);
		bddListCombo.setBounds(20, 350, 500, 30);
		closeTabButton.setBounds(60, 500, 100, 30);
		iStepDefinationPanel.add(iScenarioLabel);
		iStepDefinationPanel.add(iKeywordBDDCmbBox);
		iStepDefinationPanel.add(iBuiltInBtn);
		iStepDefinationPanel.add(iBDDText);
		iStepDefinationPanel.add(iAppMethodsbtn);
		iStepDefinationPanel.add(iScrollPane);
		iStepDefinationPanel.add(iMoveUpbtn);
		iStepDefinationPanel.add(iMoveDownbtn);
		iStepDefinationPanel.add(iCreateStepDefbtn);
		iStepDefinationPanel.add(bddListCombo);
		iStepDefinationPanel.add(closeTabButton);
		iStepDefinationPanel.setLayout(null);
		iAppMethodsbtn.addActionListener(this);
		iBuiltInBtn.addActionListener(this);
		iCreateStepDefbtn.addActionListener(this);
        closeTabButton.addActionListener(this);
        iMoveUpbtn.addActionListener(this);
        iMoveDownbtn.addActionListener(this);
	}
	
	
	public void objectExtractorPanel() {
		Object[] bddList = getListFromDB("ScenarioList").toArray();
		JLabel scenarioLabel = new JLabel("BDD Scenario List:");
		bddListObjectCombo = new JComboBox(bddList);
		addBddButton = new JButton("+");
		JLabel pageNameLabel = new JLabel("Page Name:");
		pageNameText = new JTextField();
		addObjectCallButton = new JButton("Call Extractor");
		bddScriptTextArea = new JTextArea();
		BddExeuteButton = new JButton("Execute");
		JScrollPane textpane = new JScrollPane(bddScriptTextArea);
		textpane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		textpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scenarioLabel.setBounds(10, 10, 150, 30);
		bddListObjectCombo.setBounds(220, 10, 500, 30);
		pageNameLabel.setBounds(20, 50, 100, 30);
		pageNameText.setBounds(150, 50, 180, 30);
		addObjectCallButton.setBounds(350, 50, 100, 30);
		addBddButton.setBounds(750, 10, 100, 30);
		textpane.setBounds(20, 95, 600, 200);
		BddExeuteButton.setBounds(20, 295, 100, 30);
		objectExtractPanel = new JPanel();
		objectExtractPanel.add(scenarioLabel);
		objectExtractPanel.add(pageNameLabel);
		objectExtractPanel.add(bddListObjectCombo);
		objectExtractPanel.add(pageNameText);
		objectExtractPanel.add(addObjectCallButton);
		objectExtractPanel.add(addBddButton);
		objectExtractPanel.add(textpane);
		objectExtractPanel.add(BddExeuteButton);	
		BddExeuteButton.setEnabled(false);
		objectExtractPanel.setLayout(null);
		addBddButton.addActionListener(this);
		BddExeuteButton.addActionListener(this);
		addObjectCallButton.addActionListener(this);
	}
	
	
	
	
	
	
	public String getPageName() throws SQLException {
		String pageName = null;
		String sql = "SELECT distinct [PageName] FROM ObjectDetails";
		Connection conn = SQLite.connect();  
		 Statement stmt  = conn.createStatement();
		 ResultSet rs;
		rs = stmt.executeQuery(sql);		 
		while(rs.next()) {
			pageName = rs.getString("PageName");
		
		 }
		return pageName;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 public static String insert(String scenarioName, String scenarioKey, String methodName, String Method) {  
	        String sql = "INSERT INTO scenarioList(ScenarioName, ScenarioKey, MethodName ,ScenarioMethods) VALUES(?,?,?,?)";  
	        String message = null;
	        try{  
	            Connection conn = SQLite.connect();  
	            PreparedStatement pstmt = conn.prepareStatement(sql);  
	            pstmt.setString(1, scenarioName);
	            pstmt.setString(2, scenarioKey);
	            pstmt.setString(3, methodName);
	            pstmt.setString(4, Method);
	            pstmt.executeUpdate();  
	            conn.close();
	           message = "Success - Insert Successfully";
	        } catch (SQLException e) {  
	            message = "Failed - Unable to add the scenario" + e.getMessage();
	        }
	        System.out.println(message);
			return message;  
	    } 
	 
	 
	  
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	 public void iGetBuiltInMethodsPanel() {
		try {

			iBuiltInMethodFrame = new JFrame();
			JPanel iTablePanel = new JPanel();
			Object[][] iRowData = convertToDimensionalArray(iGetBuiltInMethods());
			Object[] columnIdentifiers = { "Method Name", "Parameter1","Parameter2" ,"Parameter3" ,"Selector" };
			iBuiltInTable = new JTable(iRowData, columnIdentifiers);
			iBuiltInTable.getColumnModel().getColumn(4).setCellEditor(new DefaultCellEditor(new JCheckBox()));
			iBuiltInTable.getColumnModel().getColumn(4).setPreferredWidth(10);
			iBuiltInTable.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
				JCheckBox checkBox = new JCheckBox();

				public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
						boolean hasFocus, int row, int column) {
					checkBox.setBackground(isSelected ? UIManager.getColor("Table.selectionBackground")
							: UIManager.getColor("Table.background"));
					checkBox.setSelected(Boolean.TRUE.equals(value));
					return checkBox;
				}
			});
			
			iBuiltInTable.getModel().addTableModelListener(this);
			JScrollPane iScrollPane = new JScrollPane(iBuiltInTable);
			iTablePanel.add(iScrollPane);
			iScrollPane.setBounds(1, 5, 800, 300);			
			iBuildInMethodAddbtn = new JButton("Add");
			iBuildInMethodAddbtn.setBounds(10, 350, 100, 30);
			iBuildInMethodAddbtn.addActionListener(this);
			//sp.add(addMethodButton);
			iTablePanel.add(iBuildInMethodAddbtn);
			iTablePanel.setLayout(null);
			
			iBuiltInMethodFrame.add(iTablePanel);
			iBuiltInMethodFrame.setSize(820, 500);				  
			iBuiltInMethodFrame.setVisible(true);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
		 
		 
	 public void iGetApplicationMethodsPanel() {
		 int rowSize = 1, colSize = 3;
		 Object[] iPageList = getListFromDB("pagelist").toArray();
		 iAppMethodFrame = new JFrame("Application Methods");
		 JPanel iPageSelectionPanel = new JPanel();
		 iPageNameCmbBox = new JComboBox(iPageList);
		 iPageViewbtn = new JButton("View");
		 iPageNameCmbBox.setBounds(20, 40, 200, 100);
		 iPageNameCmbBox.setBounds(220, 40, 100, 40);
		 iPageSelectionPanel.add(iPageNameCmbBox);
		 iPageSelectionPanel.add(iPageViewbtn);
		 iAppMethodsPanel = new JPanel();
		 iAppModelTable = new DefaultTableModel();
		 iAppModelTable.addColumn("MethodName");
		 iAppModelTable.addColumn("PageName");
		 iAppModelTable.addColumn("PageName");		 
		 iAppMethodTable = new JTable(iAppModelTable);				
		 JScrollPane sp = new JScrollPane(iAppMethodTable);
		 iAppMethodAddbtn= new JButton("Create Script");
		 iAddObjects_Rbtn = new JRadioButton("Add New Objects");
		 iExistingObject_Rbtn = new JRadioButton("Existing Objects");
		 iNewMethod_Rbtn = new JRadioButton("Create Method");
		 ButtonGroup iMethodBtnGrp = new ButtonGroup();
		 iMethodBtnGrp.add(iAddObjects_Rbtn);iMethodBtnGrp.add(iExistingObject_Rbtn);iMethodBtnGrp.add(iNewMethod_Rbtn);
		 iAppMethodTable.setBounds(10, 20, 800, 300);
		 sp.setBounds(10, 20, 800, 300);
		 iAppMethodAddbtn.setBounds(830, 50, 130, 40);
		 iAddObjects_Rbtn.setBounds(40, 350, 130, 40);
		 iExistingObject_Rbtn.setBounds(180, 350, 130, 40);
		 iNewMethod_Rbtn.setBounds(320, 350, 130, 40);
		 iAppMethodsPanel.add(sp);
		 iAppMethodsPanel.add(iAppMethodAddbtn);
		 iAppMethodsPanel.add(iAddObjects_Rbtn);
		 iAppMethodsPanel.add(iExistingObject_Rbtn);
		 iAppMethodsPanel.add(iNewMethod_Rbtn);
		 iAppMethodsPanel.setLayout(null);
		 iAppMethodFrame.add(iAppMethodsPanel);
		 iAppMethodFrame.getContentPane().add(BorderLayout.NORTH, iPageSelectionPanel);		 
		 iAppMethodFrame.setExtendedState(iAppMethodFrame.getExtendedState() | JFrame.MAXIMIZED_BOTH);
		 iAppMethodFrame.setVisible(true);
		 iAddObjects_Rbtn.addActionListener(this);
		 iExistingObject_Rbtn.addActionListener(this);
		 iNewMethod_Rbtn.addActionListener(this);
		 iPageViewbtn.addActionListener(this);
		 iAppMethodAddbtn.addActionListener(this);
		 iAppMethodTable.getModel().addTableModelListener(this);
	 }
	 
	 
	 public void tableChanged(TableModelEvent e) {
			System.out.println(e);
			if(iAppMethodTable != null) {
				if(e.getSource() == iAppMethodTable.getModel()) {
					int row = iAppMethodTable.getSelectedRow();				
					int column = iAppMethodTable.getSelectedColumn();
					System.out.println(row);
					if(row >= 0) {
						String cellValue = String.valueOf(iAppMethodTable.getValueAt(row, 0));
						String cellParam = String.valueOf(iAppMethodTable.getValueAt(row, 1));
						String cellStatus = String.valueOf(iAppMethodTable.getValueAt(row, column));					
						iAppliactionMethodsMap.put(cellValue, Boolean.valueOf(cellStatus));
						iAppMethodParameterMap.put(cellValue, cellParam);
					}
			}
			
			
				
			}
			
			if(iBuiltInTable != null) {
				if(e.getSource() == iBuiltInTable.getModel()) {
					int row = iBuiltInTable.getSelectedRow();
					int column = iBuiltInTable.getSelectedColumn();;
					String cellValue = String.valueOf(iBuiltInTable.getValueAt(row, 0));
					String cellStatus = String.valueOf(iBuiltInTable.getValueAt(row, column));
					System.out.println(cellValue + cellStatus);
					iBuildInMethodsMap.put(cellValue, Boolean.valueOf(cellStatus));
					List<String> param = new ArrayList<>();
					for (int i = 1; i < iBuiltInTable.getColumnCount()-1; i++) {					
						param.add(String.valueOf(iBuiltInTable.getValueAt(row, i)));
					}
					iBuiltInParameter.put(cellValue, param);
				}
			}
			
			if(iAddObjectTable != null) {
				if(e.getSource() == iAddObjectTable.getModel()) {
					int row = iAddObjectTable.getSelectedRow();
					int column = iAddObjectTable.getSelectedColumn();;
					String cellValue = String.valueOf(iAddObjectTable.getValueAt(row, 0));
					String cellStatus = String.valueOf(iAddObjectTable.getValueAt(row, column));
					System.out.println(cellValue + cellStatus);
					
				}
			}
			
			
			
		}
	 
	 
	 
	 
	 
	 
	 
	 
	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//new iEasy();
		iEasy2 es = new iEasy2();
		es.iEasyToolExecutor();
		
	        
	}
	
	public static String bddStepDefinationGeneration(String Bdd, String Tempvalue, String methods) {
		String combinedText = null, methodName = null;
		String[] scenarios = Tempvalue.split("\"");
		int count = 0;
		for(int i=0; i <= scenarios.length; i=i+2)
		{					
			
			if (combinedText == null) {
				combinedText = scenarios[i] ;
				methodName = scenarios[i].trim();
				count++;
			}else {
				combinedText = combinedText + "\\\"([^\\\"]*)\\\"" + scenarios[i] ;
				methodName = methodName +  scenarios[i] ;
				count++;
			}
			
		}
							
		combinedText = "@" + Bdd + "(\"^" + combinedText +"$\")";
		String parameter = "";
		for(int i = 1; i< count; i++) {
			if(parameter.isEmpty()) {
				parameter = "String arg"+i;
			}else {
				parameter = parameter +  ",String arg"+i; 
			}
			
		}
		combinedText = combinedText + " \n" + methodName.replaceAll(" ", "_") + "(" +parameter+ "){\n " + methods + " \n}";
		return combinedText;
		
	 
		
	}
	
	
	public ArrayList<String> getListFromDB(String listType) {
		ArrayList<String> arrList = new ArrayList<String>();
		String sql = null;
		try {
			Connection conn = SQLite.connect();
			Statement stmt = conn.createStatement();
			ResultSet rs;
			switch (listType.toLowerCase()) {
			case "scenariolist":
				sql = "SELECT * FROM ScenarioList";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {					
					arrList.add(rs.getString("ScenarioKey") + " " + rs.getString("ScenarioName"));
				}
				break;
			case "methodlist":
				sql = "SELECT * FROM WrapperMethods";
				rs = stmt.executeQuery(sql);
				ResultSetMetaData rsmd = rs.getMetaData();
				methodListValue = new ArrayList<>(rsmd.getColumnCount());

				for (int i = 1; i < rsmd.getColumnCount(); i++) {					
					arrList.add(rsmd.getColumnName(i));
					methodListValue.add(new ArrayList<String>());
				}
				arrList.add("SelectOptions");

				while (rs.next()) {
					for (int i = 1; i < rsmd.getColumnCount(); i++) {
						methodListValue.get(i - 1).add(rs.getString(i));
					}

				}
				break;
				
			case "objectlist":
				sql = "SELECT * FROM ObjectDetails";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {
					System.err.println(rs.getString("ObjectName"));
					arrList.add(rs.getString("ObjectName"));
				}

				break;
				
			case "pagelist":
				sql = "SELECT distinct[PageName] FROM ObjectDetails";
				rs = stmt.executeQuery(sql);
				while (rs.next()) {					
					arrList.add(rs.getString("PageName"));
				}

				break;	
			default:
				break;
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arrList;

	}
	
	public void iCreateStepDefination() {
		String iBDDKey = (String) iKeywordBDDCmbBox.getItemAt(iKeywordBDDCmbBox.getSelectedIndex());
		String iBDDTextValue = iBDDText.getText();
		String iMethods = iSelectedPageName +" "+ iSelectedPageName.toLowerCase() + "= new " + iSelectedPageName+ "(getDriver());";
		for(int i = 0; i < iStepListbox.getModel().getSize(); i++) {
			iMethods = iMethods +"\n " +iSelectedPageName.toLowerCase()+ "." + iStepListbox.getModel().getElementAt(i);
			
		}	
		String methodName = bddStepDefinationGeneration(iBDDKey, iBDDTextValue, iMethods );
		//messageText.setText(insert(value, data, methodName, ""));
		System.out.println(methodName);
		bddListCombo.addItem(iBDDKey + " " + iBDDTextValue);
		messageText.setText("Please add step defination");

		
	}
	
	
	
	
	
	public void iAddNewObjects(String iTempValue) {	
		
		
			String[] iLocators = {"","Id", "Name", "Xpath", "ClassName", "tagName" };
			String[] iObjectType = {"", "Text", "Select", "Radio", "Button", "Link"};
			String[] iObjectAction = {"", "Set", "Set_List", "Get","Select", "Select_List", "Click"};
			
			iObjectModelTable = new DefaultTableModel();
					
			iAddObjectTable  = new JTable(iObjectModelTable);
			iAddObjectTable.setRowHeight(22);
			iAddObjectTable.setBounds(40, 405, 650, 250);
			iObjectScrollPane = new JScrollPane(iAddObjectTable);
	        
	        iObjectScrollPane.setBounds(40, 405, 650, 250);
	        iAppMethodsPanel.add( iObjectScrollPane);
	        
	        
	        if(iTempValue.equals("Existing Objects")) {
	        	Object[] columnIdentifiers = {"ObjectName", "Locators", "Value" };
	        	Object[][] iObjects = convertToDimensionalArray(iGetExistingObjects(iSelectedPageName));
	        	iObjectModelTable.setDataVector(iObjects, columnIdentifiers);
	        	iAddObjectTable.getModel().addTableModelListener(this);
	        	iUpdateObjectsbtn = new JButton("Update");
	        	iUpdateObjectsbtn.setBounds(700, 505, 100, 30);
	        	iAppMethodsPanel.add(iUpdateObjectsbtn);
	        	iUpdateObjectsbtn.addActionListener(this);
	        }else if(iTempValue.equals("New Objects")) {
	        	
	        	iObjectModelTable.addColumn("ObjectName");
				iObjectModelTable.addColumn("ObjectType");
				iObjectModelTable.addColumn("Action");
				iObjectModelTable.addColumn("Locators");
				iObjectModelTable.addColumn("Value"); 
	        	iAddObjectsbtn = new JButton("+");
				iDeleteObjectbtn = new JButton("-");
				iInsertObjectsbtn = new JButton("Insert");
	        	iAddObjectsbtn.setBounds(700, 425, 80, 30);
		        iDeleteObjectbtn.setBounds(700, 465, 80, 30);
		        iInsertObjectsbtn.setBounds(700, 505, 100, 30);
	        	iAppMethodsPanel.add(iAddObjectsbtn);
		        iAppMethodsPanel.add(iDeleteObjectbtn);
		        iAppMethodsPanel.add(iInsertObjectsbtn);
		        iObjectModelTable.addRow(new Object[] { "", "", "", "", ""});
		        TableColumn iActionsCol =   iAddObjectTable.getColumnModel().getColumn(2);
		        iActionsCol.setCellEditor(new MyComboBoxEditor(iObjectAction));
		        iActionsCol.setCellRenderer(new MyComboBoxRenderer(iObjectAction));
		        TableColumn ilocatorsCol =   iAddObjectTable.getColumnModel().getColumn(3);
		        ilocatorsCol.setCellEditor(new MyComboBoxEditor(iLocators));
		        ilocatorsCol.setCellRenderer(new MyComboBoxRenderer(iLocators));
		        TableColumn iObjectTypeCol =   iAddObjectTable.getColumnModel().getColumn(1);
		        iObjectTypeCol.setCellEditor(new MyComboBoxEditor(iObjectType));
		        iObjectTypeCol.setCellRenderer(new MyComboBoxRenderer(iObjectType));
		        iAddObjectsbtn.addActionListener(this);
		        iDeleteObjectbtn.addActionListener(this);
		        iInsertObjectsbtn.addActionListener(this);
	        }else if(iTempValue.equals("New Method")) {
	        	iObjectModelTable.addColumn("ObjectName");
				iObjectModelTable.addColumn("Action");
				Object[] iObjects =  iGetObjects().toArray();
	        	iObjectModelTable.addRow(new Object[] { "", ""});
	        	TableColumn iObjectCol =   iAddObjectTable.getColumnModel().getColumn(0);
	        	iObjectCol.setCellEditor(new MyComboBoxEditor(iObjects));
	        	iObjectCol.setCellRenderer(new MyComboBoxRenderer(iObjects));
	        	TableColumn iActionsCol =   iAddObjectTable.getColumnModel().getColumn(1);
		        iActionsCol.setCellEditor(new MyComboBoxEditor(iObjectAction));
		        iActionsCol.setCellRenderer(new MyComboBoxRenderer(iObjectAction));
	        }
	        
	       
			iAppMethodFrame.repaint();
			iAppMethodFrame.setVisible(true);
			
			
		}
	
	
	public void removeTable() {
		if(iObjectOptions != null) {
			if(iObjectOptions.equalsIgnoreCase("New Objects")) {
				iAppMethodsPanel.remove(iObjectScrollPane);
				 iAppMethodsPanel.remove(iAddObjectsbtn);
				 iAppMethodsPanel.remove(iDeleteObjectbtn);
				 iAppMethodsPanel.remove(iInsertObjectsbtn);
			}else if(iObjectOptions.equalsIgnoreCase("Existing Objects")) {
				iAppMethodsPanel.remove(iObjectScrollPane);
				iAppMethodsPanel.remove(iUpdateObjectsbtn);
			}else if(iObjectOptions.equalsIgnoreCase("New Method")) {
				iAppMethodsPanel.remove(iObjectScrollPane);
			}
			
				iAppMethodFrame.repaint();
				 iAppMethodFrame.setVisible(true);
		}
		
		
		
		 
	}
		
       
        
		
	
	
	
	public List<String> iGetObjects() {
		List<String> arrList = new ArrayList<String>();
		 
		 try {
			 Connection conn = SQLite.connect();;
			 Statement stmt = conn.createStatement();
			ResultSet rs;
			String sql = "SELECT ObjectName FROM Objects WHERE PageName = '" + iSelectedPageName + "'";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
					arrList.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return arrList;
		 
	
	}
	
	
	
	public void iInsertObjects() {
		int rowCount = iAddObjectTable.getRowCount();
		 Connection conn = null;
		 PreparedStatement pstmt;
		for (int i = 0; i < rowCount; i++) {
			if (!String.valueOf(iAddObjectTable.getValueAt(i, 0)).isEmpty()) {
				StringBuffer iMethodName = new StringBuffer();
				StringBuffer iObjectName = new StringBuffer(String.valueOf(iAddObjectTable.getValueAt(i, 0)));
				StringBuffer iObjectType = new StringBuffer(String.valueOf(iAddObjectTable.getValueAt(i, 1)));
				StringBuffer iObjectAction = new StringBuffer(String.valueOf(iAddObjectTable.getValueAt(i, 2)));
				StringBuffer iObjectLocators = new StringBuffer(String.valueOf(iAddObjectTable.getValueAt(i, 3)));
				StringBuffer iObjectProperty = new StringBuffer(String.valueOf(iAddObjectTable.getValueAt(i, 4)));

				switch (iObjectAction.toString().toLowerCase()) {
				case "set":
					iMethodName.append("enter_" + iObjectName);
					break;
				case "click":
					iMethodName.append("click_" + iObjectName);
					break;
				case "select":
					iMethodName.append("select_" + iObjectName);
					break;
				case "select_list":
					iMethodName.append("select_List_" + iObjectName);
					break;
				
					
				default:
					break;
				}
				String iSqlObjects = "INSERT INTO Objects(PrimaryObjects, ObjectName, ObjectType, PageName ,Locators, Property)"
						+ "VALUES(?,?,?,?,?,?)";
				String iSqlObjectDetails = "INSERT INTO ObjectDetails(ObjectName, Action, MethodName ,ExcelField, PageName)" 
							+"VALUES(?,?,?,?,?)";
		        try{  
		            conn = SQLite.connect();  
		            pstmt = conn.prepareStatement(iSqlObjects);  
		            pstmt.setString(1, iSelectedPageName + "_"+ iObjectName.toString());
		            pstmt.setString(2, iObjectName.toString());
		            pstmt.setString(3, iObjectType.toString());
		            pstmt.setString(4, iSelectedPageName);
		            pstmt.setString(5, iObjectLocators.toString());
		            pstmt.setString(6, iObjectProperty.toString());
		            pstmt.executeUpdate();  
		            pstmt = conn.prepareStatement(iSqlObjectDetails);
		            pstmt.setString(1, iObjectName.toString());
		            pstmt.setString(2, iObjectAction.toString());
		            pstmt.setString(3, iMethodName.toString());
		            pstmt.setString(4, iObjectName.toString());
		            pstmt.setString(5, iSelectedPageName);
		            pstmt.executeUpdate(); 
		            conn.close();
		           for(int j = rowCount; j > 0 ; j--) {
		   			iObjectModelTable.removeRow(j-1);
		   			}	           
		           iAppModelTable.addRow(new Object[] {iMethodName.toString() , iObjectName.toString(), iObjectName.toString(), ""});
		           iObjectModelTable.addRow(new Object[] { "", "", "", "", ""});
		           createPage(iSelectedPageName);
		        } catch (SQLException e) {
		        	JOptionPane.showMessageDialog(null,"The Object '" + iObjectName.toString() + "' may exists" , "Warning:",
							JOptionPane.WARNING_MESSAGE);
		        }finally {
		        	 try {
						conn.close();
					} catch (SQLException e) {
						
					}
		        }
		        
			}
			
	        
		
		}
		
		
		
	}
	
	public static void createPage(String pageName) {
		
		HashMap<String, String> iObjectProperty = new HashMap<String, String>();
		HashMap<String, String> iObjectAction = new HashMap<String, String>();
		String sql = "SELECT obj.ObjectName as ObjectName, obj.Locators as Locators,  objDtl.Action as Action FROM Objects AS obj, ObjectDetails AS objDtl WHERE obj.objectname = objDtl.objectname and obj.pagename =objDtl.pagename and  obj.PageName = '" + pageName + "'";
		try {
				Connection conn = SQLite.connect();
				Statement stmt = conn.createStatement();
				ResultSet rs;
				rs = stmt.executeQuery(sql);
				File javaFile = new File("./src/test/java/TechMQA/" +pageName + ".java");	
				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(javaFile)));
				writer.write("package TechMQA;\n\n");	
				writer.write("import java.util.List;\nimport org.openqa.selenium.By;\nimport org.openqa.selenium.By;\r\n" + 
						"import org.openqa.selenium.WebElement;\r\n" + 
						"import org.openqa.selenium.support.FindBy;\r\n" + 
						"import utilities.CoreTapWrappers;\r\n"+
						"import org.openqa.selenium.support.How;\n\n");
				writer.write("public class " + pageName + " extends CoreTapWrappers {\n\n");
				while (rs.next()) {
					iObjectProperty.put(rs.getString("ObjectName"), rs.getString("Locators"));
					iObjectAction.put(rs.getString("ObjectName"), rs.getString("Action"));
				}
				
				for(Entry<String, String> key: iObjectProperty.entrySet()) {
					writer.write("\n\n @FindBy(how=How." + key.getValue().toUpperCase() + ", using=\"" + key.getKey() +"\") WebElement " + key.getKey() +  ";" );
				}
				
				
				for(Entry<String, String> entrySets: iObjectAction.entrySet()) {
					switch (entrySets.getValue().toLowerCase()) {
					case "set":
						writer.write("\n\n");
						writer.write("\n\r public void enter_" + entrySets.getKey() + "(String temp_" + entrySets.getKey() + "){\n \t enterInputText(" + entrySets.getKey()+ ",temp_" + entrySets.getKey() + ",\"" + entrySets.getKey().replace("_", " ") + "\"); \n } ");
						
						break;
					case "click":
						writer.write("\n\n" );
						writer.write("\r\n public void click_" + entrySets.getKey() + "(){ \n \n webElementClick(" + entrySets.getKey()+ ",\"" + entrySets.getKey().replace("_", " ") + "\"); \n } ");
						
						break;
						
					case "get":
						
						break;
					case "select":
						
						break;
					case "select_list":
						writer.write("\n\n" );
						writer.write("\n\r public void selectList_" + entrySets.getKey() + "(String temp_" + entrySets.getKey() + "){\n \t  for(WebElement ele: " + entrySets.getKey() +" ) {\n\t selectVisibileText(ele ,temp_" + entrySets.getKey() + ", ele..getAttribute(\"name\")); \n } ");
						break;
					case "radiooptions":
						
						break;
					default:
						break;
					}
				}
				
				
				
				
					writer.write("\n}\n");
				
				
			    writer.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	//Action Performed
	public void actionPerformed(ActionEvent eve) {
		String data, value;
		try {
			
		

		if (eve.getSource() == iAppMethodsbtn) {
			
			iGetApplicationMethodsPanel();
			
		}else if(eve.getSource() == iPageViewbtn) {
			
			iViewApplicationMethods();
			
		}else if(eve.getSource() == iAppMethodAddbtn) {
			
			iAddApplicationMethods();
			
		}else if(eve.getSource() == iMoveUpbtn) {
			
			iNavigationAction("UP");
			
		}else if(eve.getSource() == iMoveDownbtn){
			
			iNavigationAction("Down");
			
		}else if (eve.getSource() == iBuildInMethodAddbtn) {
			
			iAddBuiltInMethods();

		}else if(eve.getSource() == iBuiltInBtn) {
			
			iGetBuiltInMethodsPanel();
			
		}else if (eve.getSource() == iCreateStepDefbtn) {
		
			iCreateStepDefination();
		
			
		}else if(eve.getSource() == iAddObjects_Rbtn) {	
			removeTable();
			iObjectOptions = "New Objects";
			iAddNewObjects(iObjectOptions);
			
		}else if(eve.getSource() == iExistingObject_Rbtn) {	
			removeTable();
			iObjectOptions = "Existing Objects";
			iAddNewObjects(iObjectOptions);
			
			
		}else if(eve.getSource() == iNewMethod_Rbtn) {
			
			removeTable();
			iObjectOptions = "New Method";
			iAddNewObjects(iObjectOptions);
		}else if(eve.getSource() == iAddObjectsbtn) {
			
			 iObjectModelTable.addRow(new Object[] { "", "", "", "", ""});
		
		
		}else if(eve.getSource() == iDeleteObjectbtn) {
			
			int rowCount = iAddObjectTable.getRowCount();
			if(rowCount>1) {
				iObjectModelTable.removeRow(rowCount-1);
			}
			
			
		}else if(eve.getSource() == iInsertObjectsbtn) {
			
			iInsertObjects();
			
		}else if (eve.getSource() == closeTabButton) {
			tabPane.remove(tabPane.getSelectedIndex());

		}  else if (eve.getSource() == iBuiltInBtn) {
			//methodList();

		} else if (eve.getSource() == addBddButton) {

			String result = null;
			data = (String) bddListObjectCombo.getItemAt(bddListObjectCombo.getSelectedIndex());
			value = bddScriptTextArea.getText();
			if (value.isEmpty()) {
				result = data;
			} else {
				result = value + "\n" + data;
			}

			bddScriptTextArea.setText(result);

		} else if (eve.getSource() == addObjectCallButton) {
			String result = null;
			if (pageNameText.getText().isEmpty()) {
				JOptionPane.showMessageDialog(null, "PageName should not be empty!", "Warning:",
						JOptionPane.WARNING_MESSAGE);
			} else {
				data = "And call Object Extractor \"" + pageNameText.getText() + "\"";
				value = bddScriptTextArea.getText();
				if (value.isEmpty()) {
					result = data;
				} else {
					result = value + "\n" + data;
				}

				bddScriptTextArea.setText(result);
				BddExeuteButton.setEnabled(true);
			}

		} else if (eve.getSource() == BddExeuteButton) {

			try {
				File javaFile = new File("./src/test/resources/features/ObjectExtractor.feature");
				BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(javaFile)));
				writer.write("Feature: Object Extractor\n\n");
				writer.write("@Regression\n\n");
				writer.write("Scenario Outline: Individual Customer creation |~ <TestName> |@ <SheetName> \n");
				writer.write(bddScriptTextArea.getText() + "\n\n");
				writer.write("Examples:\n|TestName|SheetName|\n|TC001_Object_Extraction|ObjectExraction|");
				writer.close();
				System.out.println("Batch Start");
				String[] command = { "cmd.exe", "/C", "Start", "D:\\sqlite\\test.bat" };
				Process p = Runtime.getRuntime().exec(command);

			} catch (IOException ex) {
				System.out.println(ex);
			}

		}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
	

	public void iNavigationAction(String action) {
		int moveMe = iStepListbox.getSelectedIndex();
		switch (action.toLowerCase()) {
		case "up":
			if (moveMe < 1) {
				JOptionPane.showMessageDialog(null, "Cannot be moved up", "Warning:", JOptionPane.WARNING_MESSAGE);
			} else {
				iSwapStepList(moveMe, moveMe - 1);
			}
			break;

		case "down":

			if (moveMe >= iStepListbox.getModel().getSize() - 1) {
				JOptionPane.showMessageDialog(null, "Cannot be moved down", "Warning:", JOptionPane.WARNING_MESSAGE);
			} else {
				iSwapStepList(moveMe, moveMe + 1);
			}

			break;

		default:
			break;
		}

	}
	
	
	
	public List<ArrayList<String>> iGetBuiltInMethods() {
		List<ArrayList<String>> arrList = new ArrayList<ArrayList<String>>();
		try {
			Connection conn = SQLite.connect();
			Statement stmt = conn.createStatement();
			ResultSet rs;
			String sql = "SELECT MethodName,Parameter1, Parameter2, Parameter3  FROM BuiltInMethods";
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println("The Column Count is " + rsmd.getColumnCount());
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				arrList.add(new ArrayList<String>());
			}
			while (rs.next()) {
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					System.out.println(rs.getString(i));
					arrList.get(i - 1).add(rs.getString(i));
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return arrList;
	}

	public List<ArrayList<String>> iGetApplicationMethods(String pageName){
		String sql = "SELECT distinct MethodName, ObjectName, ExcelField FROM ObjectDetails where PageName = '" + pageName
				+ "'";
		List<ArrayList<String>> arrList = iGetDataFromDB(sql);
		return arrList;
	}
	
	
	public List<ArrayList<String>> iGetExistingObjects(String pageName){
		
		String sql = "SELECT a.objectname, a.locators, a.property FROM 'Objects' as a , 'ObjectDetails' AS b WHERE a.pagename=b.pagename and a.objectname= b.objectname and a.pagename = '" + pageName
				+ "'";
		List<ArrayList<String>> arrList = iGetDataFromDB(sql);
		return arrList;
		
	}
	
	
	
	
	
	
	public List<ArrayList<String>> iGetDataFromDB(String sql) {

		List<ArrayList<String>> arrList = new ArrayList<ArrayList<String>>();
		try {
			Connection conn = SQLite.connect();
			Statement stmt = conn.createStatement();
			ResultSet rs;
			rs = stmt.executeQuery(sql);			
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println("The Column Count is " + rsmd.getColumnCount());
			for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				arrList.add(new ArrayList<String>());
			}
			while (rs.next()) {
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					
					arrList.get(i - 1).add(rs.getString(i));
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return arrList;
	}

	public Object[][] convertToDimensionalArray(List<ArrayList<String>> arrList) {
		int iRowSize = arrList.size();
		int iColSize = arrList.get(0).size();
		Object data[][] = new Object[iColSize][iRowSize + 1];
		for (int j = 0; j < iColSize; j++) {
			for (int i = 0; i < iRowSize; i++) {
				if (i == iRowSize) {
					data[j][i] = Boolean.FALSE;
				} else {
					System.out.println(arrList.get(i).get(j).toString());
					data[j][i] = arrList.get(i).get(j).toString();
				}
			}
		}

		return data;
	}
	
	

	
	
	
	
	

	public void iViewApplicationMethods() {
		String pageName = (String) iPageNameCmbBox.getItemAt(iPageNameCmbBox.getSelectedIndex());
		iSelectedPageName = pageName;
		Object[][] rowData = convertToDimensionalArray(iGetApplicationMethods(pageName));
		Object[] columnIdentifiers = { "Method Name", "Object Name", "Input Field", "Selector" };
		iAppModelTable.setDataVector(rowData, columnIdentifiers);
		iAppMethodTable.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(new JCheckBox()));
		iAppMethodTable.getColumnModel().getColumn(3).setPreferredWidth(10);
		iAppMethodTable.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
			JCheckBox checkBox = new JCheckBox();

			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
					boolean hasFocus, int row, int column) {
				checkBox.setBackground(isSelected ? UIManager.getColor("Table.selectionBackground")
						: UIManager.getColor("Table.background"));
				checkBox.setSelected(Boolean.TRUE.equals(value));

				setOpaque(true);
				return checkBox;
			}
		});

		
	}
	
	public void iAddApplicationMethods() {
		
		String pageName = (String) iPageNameCmbBox.getItemAt(iPageNameCmbBox.getSelectedIndex());
		for (String key : iAppliactionMethodsMap.keySet()) {
			if (iAppliactionMethodsMap.get(key)) {
				if (!iAppMethodParameterMap.get(key).equals("")) {
					iStepListModel
							.addElement(key + "(excelHashMapValues.get(\"" + iAppMethodParameterMap.get(key) + "\"))");
				} else {
					iStepListModel.addElement(key + "()");
				}

				iAppMethodFrame.dispose();

			}
		}
		
	}

	
	public void iAddBuiltInMethods() {
		String methods = "";
		for (String key : iBuildInMethodsMap.keySet()) {
			if (iBuildInMethodsMap.get(key)) {
				String parameter = null;
				List<String> Temp = iBuiltInParameter.get(key);
				for (String param : Temp) {
					if (!param.isEmpty()) {
						if (parameter == null) {
							parameter = param;
						} else {
							parameter = parameter + "," + param;
						}

					}
				}
				iStepListModel.addElement(key + "(" + parameter + ")");
			}
		}
		
		System.out.println(methods);

		iBuiltInMethodFrame.dispose();
		
	}
	
		
	

}






